
import React, { useState, useEffect, useCallback, createContext, useContext, useMemo } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { HomeScreen, ShalwarKameezFormScreen, PantShirtFormScreen, OrderListScreen, OrderDetailScreen, ProfileScreen } from './views'; 
import { Header, Footer } from './uiElements'; 
import { Theme, Language } from './types';
import { APP_CONFIG, LANG_STRINGS } from './dataAndContent';

// Theme Context
interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// Language Context
interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  strings: typeof LANG_STRINGS[Language.Urdu]; // Type it based on one of the language string sets
}
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};


const App: React.FC = () => {
  const [theme, setTheme] = useState<Theme>(() => {
    const storedTheme = localStorage.getItem('darziMasterTheme') as Theme | null;
    return storedTheme || Theme.Light;
  });

  const [language, setLanguageState] = useState<Language>(() => {
    const storedLanguage = localStorage.getItem('darziMasterLanguage') as Language | null;
    return storedLanguage || Language.Urdu; // Default to Urdu
  });

  const [isLoadingApp, setIsLoadingApp] = useState(true);

  useEffect(() => {
    if (theme === Theme.Dark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darziMasterTheme', theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === Language.Urdu ? 'rtl' : 'ltr';
    // Apply font class to body for global font styling based on language
    if (language === Language.Urdu) {
      document.body.classList.add('font-jameel'); // This will use 'Jameel Noori Nastaleeq' via Tailwind from index.html
      document.body.classList.remove('font-sans');
    } else {
      document.body.classList.add('font-sans'); // Default Tailwind sans-serif
      document.body.classList.remove('font-jameel');
    }
    localStorage.setItem('darziMasterLanguage', language);
  }, [language]);


  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoadingApp(false);
    }, 1500); 
    return () => clearTimeout(timer);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(prevTheme => prevTheme === Theme.Light ? Theme.Dark : Theme.Light);
  }, []);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
  }, []);

  const languageStrings = useMemo(() => LANG_STRINGS[language], [language]);

  if (isLoadingApp) {
    const fontClass = language === Language.Urdu ? 'font-jameel' : 'font-sans';
    return (
      <div className={`fixed inset-0 bg-gray-100 dark:bg-darkBg flex flex-col justify-center items-center transition-opacity duration-500 ease-in-out ${fontClass}`} dir={language === Language.Urdu ? 'rtl' : 'ltr'}>
        <h1 className="text-4xl sm:text-5xl font-bold text-primary dark:text-primary-light">
          Darzi Master
        </h1>
        <p className="text-xl sm:text-2xl text-gray-700 dark:text-darkTextSecondary mt-3">
          By Rana Asif Ali
        </p>
      </div>
    );
  }
  
  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <LanguageContext.Provider value={{ language, setLanguage, strings: languageStrings }}>
        <HashRouter>
          <div className={`flex flex-col min-h-screen ${language === Language.Urdu ? 'font-jameel' : 'font-sans'} bg-gray-50 dark:bg-darkBg text-gray-900 dark:text-darkText`}
               dir={language === Language.Urdu ? 'rtl' : 'ltr'}>
            <main className="flex-grow container mx-auto px-0 sm:px-4 py-2 sm:py-6">
              <Routes>
                <Route path="/" element={<HomeScreen />} />
                <Route path="/profile" element={<ProfileScreen />} />
                <Route path="/new/shalwar-kameez" element={<ShalwarKameezFormScreen />} />
                <Route path="/edit/shalwar-kameez/:orderId" element={<ShalwarKameezFormScreen />} />
                <Route path="/new/pant-shirt" element={<PantShirtFormScreen />} />
                <Route path="/edit/pant-shirt/:orderId" element={<PantShirtFormScreen />} />
                <Route path="/orders" element={<OrderListScreen />} />
                <Route path="/order/:orderId" element={<OrderDetailScreen />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </HashRouter>
      </LanguageContext.Provider>
    </ThemeContext.Provider>
  );
};

export default App;
