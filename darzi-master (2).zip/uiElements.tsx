
import React from 'react';
import { Link } from 'react-router-dom';
import { APP_CONFIG, IconChevronLeft, IconChevronRight, IconSave, IconStarFilled, IconStarOutline, IconHome, IconProfile as IconProfileUser, IconLanguage as IconLangSwitch } from './dataAndContent'; // Renamed IconProfile to IconProfileUser to avoid conflict
import { Theme, InputNumericProps, SelectProps, RadioGroupProps, ToggleSwitchProps, Order, GarmentType, Measurement, TailorProfile, Language } from './types';
import { getDisplayKey, getDisplayValue } from './views'; 
import { useLanguage } from './App'; // Import useLanguage

// Header Component
export const Header: React.FC<{ currentTheme: Theme; toggleTheme: () => void; showBackButton?: boolean; title?: string | null }> = ({ currentTheme, toggleTheme, showBackButton, title }) => {
  const IconSun = React.lazy(() => import('./dataAndContent').then(module => ({ default: module.IconSun })));
  const IconMoon = React.lazy(() => import('./dataAndContent').then(module => ({ default: module.IconMoon })));
  const { language, setLanguage, strings } = useLanguage();

  const handleLanguageToggle = () => {
    setLanguage(language === Language.Urdu ? Language.English : Language.Urdu);
  };

  return (
    <header className="bg-primary dark:bg-darkSurface text-white shadow-modern-md sticky top-0 z-50 print:hidden">
      <div className="container mx-auto px-3 sm:px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-1 sm:gap-2">
          {showBackButton && (
            <Link to="/" className="p-2.5 rounded-full hover:bg-primary-light/70 dark:hover:bg-darkSurfaceElevated transition-colors" aria-label={strings.back}>
              {language === Language.Urdu ? <IconChevronRight className="w-5 h-5 sm:w-6 sm:h-6" /> : <IconChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />}
            </Link>
          )}
           <Link to="/" className="p-2.5 rounded-full hover:bg-primary-light/70 dark:hover:bg-darkSurfaceElevated transition-colors" aria-label={strings.home}>
            <IconHome className="w-5 h-5 sm:w-6 sm:h-6" />
          </Link>
          {title !== null && (
            <h1 className="text-lg sm:text-xl md:text-2xl font-semibold tracking-tight">{title || strings.appName}</h1>
          )}
        </div>
        <div className="flex items-center gap-1 sm:gap-2">
          <Link to="/profile" className="p-2.5 rounded-full hover:bg-primary-light/70 dark:hover:bg-darkSurfaceElevated transition-colors" aria-label={strings.tailorProfile}>
            <IconProfileUser className="w-5 h-5 sm:w-6 sm:h-6" />
          </Link>
          <button
            onClick={handleLanguageToggle}
            className="p-2.5 rounded-full hover:bg-primary-light/70 dark:hover:bg-darkSurfaceElevated transition-colors"
            aria-label={strings.language}
          >
            <IconLangSwitch className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
          <button
            onClick={toggleTheme}
            className="p-2.5 rounded-full hover:bg-primary-light/70 dark:hover:bg-darkSurfaceElevated transition-colors"
            aria-label={currentTheme === Theme.Light ? strings.darkTheme : strings.lightTheme}
          >
            <React.Suspense fallback={<div className="w-5 h-5 sm:w-6 sm:h-6"></div>}>
              {currentTheme === Theme.Light ? <IconMoon className="w-5 h-5 sm:w-6 sm:h-6" /> : <IconSun className="w-5 h-5 sm:w-6 sm:h-6" />}
            </React.Suspense>
          </button>
        </div>
      </div>
    </header>
  );
};

// Footer Component
export const Footer: React.FC = () => {
  return (
    <footer className="bg-secondary dark:bg-darkBg text-center py-5 mt-auto border-t border-gray-200 dark:border-darkSurfaceElevated print:hidden">
      <p className="text-xs text-gray-500 dark:text-darkTextSecondary">
        {APP_CONFIG.copyrightText}
      </p>
    </footer>
  );
};

// Button Component
export const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'danger' | 'accent', icon?: React.ReactNode, fullWidth?: boolean, size?: 'sm' | 'md' | 'lg' }> = ({ children, className, variant = 'primary', icon, fullWidth, size = 'md', ...props }) => {
  const { language } = useLanguage();
  
  const sizeStyles = {
    sm: "text-xs px-3 py-1.5 rounded-md",
    md: "text-sm px-5 py-2.5 rounded-lg",
    lg: "text-base px-6 py-3 rounded-xl",
  };

  const baseStyle = `font-medium text-center inline-flex items-center justify-center transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-darkBg shadow-modern-sm hover:shadow-modern-md active:shadow-modern-sm disabled:opacity-60 disabled:cursor-not-allowed`;
  
  const variantStyles = {
    primary: "bg-primary hover:bg-primary-light dark:bg-primary dark:hover:bg-primary-dark text-white focus:ring-primary-dark",
    secondary: "bg-gray-200 hover:bg-gray-300 dark:bg-darkSurfaceElevated dark:hover:bg-gray-600 text-gray-800 dark:text-darkText focus:ring-gray-400 dark:focus:ring-gray-500",
    danger: "bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 text-white focus:ring-red-500",
    accent: "bg-accent hover:bg-accent-light dark:bg-accent dark:hover:bg-accent-dark text-white focus:ring-accent-dark",
  };
  const widthStyle = fullWidth ? "w-full" : "";
  const iconMargin = language === Language.Urdu ? "ms-2 -me-0.5" : "me-2 -ms-0.5";


  return (
    <button
      className={`${baseStyle} ${sizeStyles[size]} ${variantStyles[variant]} ${widthStyle} ${className || ''}`}
      {...props}
    >
      {icon && <span className={iconMargin}>{icon}</span>}
      {children}
    </button>
  );
};

// InputNumeric Component
export const InputNumeric: React.FC<InputNumericProps> = ({ label, value, onChange, unit, placeholder, min, max, step }) => {
  const { language, strings } = useLanguage();
  const displayUnit = unit || (language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit);
  const unitMargin = language === Language.Urdu ? "mr-2.5" : "ml-2.5"; // Using Tailwind margin for LTR/RTL consistency
  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{label}</label>
      <div className="flex items-center">
        <input
          type="text" 
          inputMode="decimal" 
          value={value}
          onChange={(e) => {
            const sanitizedValue = e.target.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
            onChange(sanitizedValue);
          }}
          placeholder={placeholder || "0"}
          min={min}
          max={max}
          step={step}
          className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"
        />
        {displayUnit && <span className={`${unitMargin} text-sm text-gray-500 dark:text-darkTextSecondary flex-shrink-0`}>{displayUnit}</span>}
      </div>
    </div>
  );
};

// Select Component
export const Select: React.FC<SelectProps> = ({ label, value, onChange, options, placeholder }) => {
  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring appearance-none bg-no-repeat bg-right pr-8"
        style={{
            backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
            backgroundPosition: `right ${useLanguage().language === Language.Urdu ? '0.5rem' : ''} center`,
            paddingRight: useLanguage().language === Language.Urdu ? '0.75rem' : '2.5rem',
            paddingLeft: useLanguage().language === Language.Urdu ? '2.5rem' : '0.75rem',
        }}
      >
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(opt => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  );
};

// RadioGroup Component
export const RadioGroup: React.FC<RadioGroupProps> = ({ label, name, options, selectedValue, onChange }) => {
  const { language } = useLanguage();
  const spanMargin = language === Language.Urdu ? "mr-2" : "ml-2";
  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-2">{label}</label>
      <div className="flex flex-wrap gap-x-5 gap-y-2.5">
        {options.map(opt => (
          <label key={opt.value} className="inline-flex items-center cursor-pointer group">
            <input
              type="radio"
              name={name}
              value={opt.value}
              checked={selectedValue === opt.value}
              onChange={(e) => onChange(e.target.value)}
              className="form-radio h-4 w-4 text-primary dark:text-primary-dark border-gray-300 dark:border-gray-500 focus:ring-primary dark:focus:ring-primary-dark bg-gray-100 dark:bg-darkSurfaceElevated"
            />
            <span className={`${spanMargin} text-sm text-gray-700 dark:text-darkTextSecondary group-hover:text-primary dark:group-hover:text-primary-light transition-colors`}>{opt.label}</span>
            {opt.icon && <span className={`opacity-70 group-hover:opacity-100 transition-opacity ${language === Language.Urdu ? "mr-1" : "ml-1"}`}>{opt.icon}</span>}
          </label>
        ))}
      </div>
    </div>
  );
};

// ToggleSwitch Component
export const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ label, checked, onChange, id }) => {
  const { language } = useLanguage();
  return (
    <div className="flex items-center justify-between w-full py-1">
      <label htmlFor={id} className="text-sm font-medium text-gray-700 dark:text-darkTextSecondary cursor-pointer">{label}</label>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        id={id}
        onClick={() => onChange(!checked)}
        className={`${
          checked ? 'bg-primary dark:bg-primary-dark' : 'bg-gray-300 dark:bg-gray-600'
        } relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary dark:focus:ring-primary-dark focus:ring-offset-2 dark:focus:ring-offset-darkBg`}
      >
        <span
          aria-hidden="true"
          className={`${
            checked ? (language === Language.Urdu ? '-translate-x-5' : 'translate-x-5') : 'translate-x-0'
          } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
        />
      </button>
    </div>
  );
};

// Loading Spinner
export const LoadingSpinner: React.FC = () => {
  const { strings, language } = useLanguage();
  const textMargin = language === Language.Urdu ? "mr-3" : "ml-3";
  return (
    <div className="flex flex-col justify-center items-center py-12 space-y-4">
      <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-primary dark:border-primary-light"></div>
      <p className={`${textMargin} text-md text-gray-500 dark:text-darkTextSecondary`}>{strings.pleaseWait}</p>
    </div>
  );
};

// OrderCard Component
export const OrderCard: React.FC<{ order: Order; onClick: () => void; onToggleFavorite: (id: string, isFavorite: boolean) => void; }> = ({ order, onClick, onToggleFavorite }) => {
  const { strings, language } = useLanguage();
  const garmentTypeLabel = order.garmentType === GarmentType.ShalwarKameez ? strings.shalwarKameezTailoring : strings.pantShirtTailoring;
  
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(order.id, !order.isFavorite);
  };

  const dateLocale = language === Language.Urdu ? 'ur-PK' : 'en-US';

  return (
    <div 
      className="bg-white dark:bg-darkSurface shadow-modern-md rounded-xl p-5 cursor-pointer hover:shadow-modern-lg hover:-translate-y-1 transition-all duration-300 ease-in-out relative group"
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && onClick()}
    >
      <button 
        onClick={handleFavoriteClick}
        className={`absolute top-3.5 ${language === Language.Urdu ? 'start-3.5' : 'end-3.5'} p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-darkSurfaceElevated transition-colors z-10`}
        aria-label={order.isFavorite ? strings.removeFavorite : strings.addFavorite}
      >
        {order.isFavorite ? <IconStarFilled className="w-6 h-6 text-yellow-400 dark:text-yellow-500" /> : <IconStarOutline className="w-6 h-6 text-gray-400 dark:text-gray-500 group-hover:text-yellow-400 transition-colors" />}
      </button>
      <div className="mb-3.5">
        <h3 className="text-lg font-semibold text-primary dark:text-primary-light group-hover:text-primary-dark dark:group-hover:text-primary transition-colors pr-8">{order.orderNumber}</h3>
        <p className="text-md text-gray-800 dark:text-darkText">{order.customerName}</p>
      </div>
      <p className="text-sm text-gray-600 dark:text-darkTextSecondary mb-1.5">{strings.garmentType}: {garmentTypeLabel}</p>
      <p className="text-sm text-gray-500 dark:text-darkTextSecondary">
        {strings.orderDate}: {new Date(order.createdAt).toLocaleDateString(dateLocale, { year: 'numeric', month: 'short', day: 'numeric' })}
      </p>
      {order.deliveryDate && (
          <p className="text-sm text-accent dark:text-accent-light mt-1.5 font-medium">
              {strings.deliveryDate}: {new Date(order.deliveryDate).toLocaleDateString(dateLocale, { year: 'numeric', month: 'short', day: 'numeric' })}
          </p>
      )}
      <div className={`mt-5 pt-3.5 border-t border-gray-200 dark:border-darkSurfaceElevated flex ${language === Language.Urdu ? 'justify-start' : 'justify-end'}`}>
        <span className="text-xs font-medium text-primary dark:text-primary-light group-hover:underline">
          {strings.orderDetails} 
          {language === Language.Urdu ? <IconChevronLeft className="inline w-3.5 h-3.5" /> : <IconChevronRight className="inline w-3.5 h-3.5" />}
        </span>
      </div>
    </div>
  );
};

// PrintableLabelContent Component
export const PrintableLabelContent: React.FC = () => { 
    const { strings, language } = useLanguage();
    const dir = language === Language.Urdu ? 'rtl' : 'ltr';
    const font = language === Language.Urdu ? '"Jameel Noori Nastaleeq", "Noto Nastaliq Urdu", sans-serif' : '"Inter", sans-serif';
    return (
      <div dir={dir} className="p-3 border border-black text-black bg-white" style={{ width: '3.5in', height: '2in', fontFamily: font, fontSize: '10pt', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          <h2 className="text-center font-bold text-lg mb-1.5">{strings.appName} - {strings.label}</h2>
          <p className="text-sm my-0.5"><strong>{strings.orderNumber}:</strong> ........................................</p>
          <p className="text-sm my-0.5"><strong>{strings.customerName}:</strong> ......................................</p>
          <p className="text-sm my-0.5"><strong>{strings.clothVariety}:</strong> ......................................</p>
          
          <div className="mt-1.5 border-t border-black pt-1">
            <h3 className="font-semibold text-xs mb-0.5">{strings.manualMeasurementsHeading}:</h3>
            <div className="grid grid-cols-2 gap-x-2 text-xs">
              <p><strong>{strings.lengthLabel}:</strong> ..........................</p>
              <p><strong>{strings.chest}:</strong> .............................</p>
              <p><strong>{strings.waist}:</strong> .............................</p>
              <p><strong>{strings.sleeveLabelForLabel}:</strong> ..........................</p>
            </div>
          </div>
        </div>
        <p className="text-center text-xs mt-1.5">{APP_CONFIG.copyrightText}</p>
      </div>
    );
  };

// PrintableReceiptContent Component (Revamped)
export const PrintableReceiptContent: React.FC<{ order: Order; tailorProfile: TailorProfile | null }> = ({ order, tailorProfile }) => {
  const { strings, language } = useLanguage();
  const dir = language === Language.Urdu ? 'rtl' : 'ltr';
  const dateLocale = language === Language.Urdu ? 'ur-PK' : 'en-US';
  const font = language === Language.Urdu ? '"Jameel Noori Nastaleeq", "Noto Nastaliq Urdu", sans-serif' : '"Inter", Arial, sans-serif';
  
  const currentShopName = tailorProfile?.shopName || strings.shopName || APP_CONFIG.appName;
  const currentTailorName = tailorProfile?.tailorName;
  const currentShopContact = tailorProfile?.phone || APP_CONFIG.developerContact;
  const currentShopAddress = tailorProfile?.address;

  return (
    <div dir={dir} className="p-6 bg-white text-black" style={{ fontFamily: font, fontSize: '11pt', width: '210mm', minHeight: '297mm', lineHeight: '1.6' }}>
      {/* Header */}
      <div className="text-center mb-8 pb-5 border-b-2 border-gray-700">
        <h1 className="text-4xl font-bold mb-2 text-gray-800">{currentShopName}</h1>
        {currentTailorName && <p className="text-xl font-medium text-gray-700">{currentTailorName}</p>}
        {currentShopAddress && <p className="text-md mt-1.5 text-gray-600">{currentShopAddress}</p>}
        <p className="text-md mt-1.5 text-gray-600">{strings.phoneLabel}: {currentShopContact}</p>
      </div>
      
      <div className="flex justify-between items-center mb-8">
         <h2 className="text-3xl font-semibold text-gray-800">{strings.receipt}</h2>
         <div className={language === Language.Urdu ? 'text-left' : 'text-right'}>
            <p className="text-sm"><strong>{strings.orderNumber}:</strong> {order.orderNumber}</p>
            <p className="text-sm"><strong>{strings.orderDate}:</strong> {new Date(order.createdAt).toLocaleDateString(dateLocale, { year: 'numeric', month: 'long', day: 'numeric' })}</p>
         </div>
      </div>


      {/* Customer Details */}
      <div className="mb-8 p-5 border border-gray-400 rounded-lg bg-gray-50">
        <h3 className="text-xl font-semibold mb-3 text-primary">{strings.customerName}: {order.customerName}</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-5 gap-y-2 text-sm">
          {order.customerMobile && <p><strong>{strings.customerMobile}:</strong> {order.customerMobile}</p>}
          {order.deliveryDate && <p><strong>{strings.deliveryDate}:</strong> {new Date(order.deliveryDate).toLocaleDateString(dateLocale, { dateStyle: 'long' })}</p>}
          <p><strong>{strings.garmentType}:</strong> {order.garmentType === GarmentType.ShalwarKameez ? strings.shalwarKameezTailoring : strings.pantShirtTailoring}</p>
        </div>
      </div>

      {/* Measurements and Style Choices */}
      {(Object.keys(order.measurements).length > 0 || (order.styleChoices && Object.keys(order.styleChoices).filter(k => order.styleChoices && order.styleChoices[k] !== undefined && order.styleChoices[k] !== null && order.styleChoices[k] !== '' && (typeof order.styleChoices[k] !== 'boolean' || order.styleChoices[k] === true)).length > 0)) && (
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-3 pb-2 border-b border-gray-400 text-gray-700">{strings.measurements} & {strings.styleChoices}</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-2.5 text-sm">
            {Object.entries(order.measurements).map(([key, value]) => {
                const displayVal = getDisplayValue(key, value, language);
                if (displayVal === '-' || displayVal === strings.no) return null;
                return <p key={`m-${key}`}><strong className="text-gray-600">{getDisplayKey(key, strings)}:</strong> {displayVal}</p>;
            })}
            {order.styleChoices && Object.entries(order.styleChoices).map(([key, value]) => {
               if (value === undefined || value === null || value === '' || (typeof value === 'boolean' && !value)) return null;
              return <p key={`s-${key}`}><strong className="text-gray-600">{getDisplayKey(key, strings)}:</strong> {getDisplayValue(key, value, language, strings)}</p>;
            })}
          </div>
        </div>
      )}

      {/* Notes */}
      {order.notes && (
        <div className="mb-10">
          <h3 className="text-xl font-semibold mb-2 text-gray-700">{strings.notes}</h3>
          <p className="whitespace-pre-wrap border p-4 rounded-md border-gray-300 bg-gray-50 text-sm leading-relaxed">{order.notes}</p>
        </div>
      )}

      {/* Footer */}
      <div className="mt-16 pt-8 border-t-2 border-gray-700 text-center">
        <p className="text-lg font-semibold text-gray-700">{strings.thankYouVisitAgain}</p>
        <p className="text-xs mt-5 text-gray-500">{APP_CONFIG.copyrightText}</p>
      </div>
    </div>
  );
};