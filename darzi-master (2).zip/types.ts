
export enum Theme {
  Light = 'light',
  Dark = 'dark',
}

export enum Language {
  Urdu = 'ur',
  English = 'en',
}

export enum GarmentType {
  ShalwarKameez = 'shalwarKameez',
  PantShirt = 'pantShirt',
}

export interface Measurement {
  value: string; // Stored as string to allow empty initial state, parsed to number for calcs
  unit: string; // e.g., "انچ"
}

export interface ShalwarMeasurements {
  waistbandThickness: Measurement;
  pocketType: string; // 'side', 'front', 'none'
  bottomHem: Measurement;
  pajamaStyle: string; // 'open', 'tight'
  // Add more Shalwar specific fields
}

export interface KameezMeasurements {
  chest: Measurement;
  waist: Measurement;
  hips: Measurement;
  shoulder: Measurement;
  sleeveLength: Measurement;
  sleeveWidth: Measurement;
  collarSize: Measurement;
  neckOpening: Measurement;
  collarStyle: string; // 'ban', 'collar', 'round', 'v-neck', 'sherwani'
  frontPocket: boolean;
  frontPocketStyle?: string; // 'single', 'double', 'straight', 'angled'
  sideCut: boolean;
  cuffThickness: Measurement; 
  // Add more Kameez specific fields
}

export interface PantMeasurements {
  waist: Measurement;
  hip: Measurement;
  thigh: Measurement;
  length: Measurement;
  frontPockets: number;
  backPockets: number;
  beltLoops: number;
  closureType: string; // 'zip', 'button'
  // Add more Pant specific fields
}

export interface ShirtMeasurements {
  collar: Measurement;
  cuff: Measurement;
  shoulder: Measurement;
  chest: Measurement;
  sleeveLength: Measurement;
  sleeveWidth: Measurement;
  frontButtonOption: string; // 'full', 'half', 'none'
  pocketOption: string; // 'one', 'two', 'none'
  // Add more Shirt specific fields
}

export interface Order {
  id: string;
  orderNumber: string; // Could be auto-generated or user-defined
  customerName: string;
  customerMobile?: string; // New field
  garmentType: GarmentType;
  measurements: Partial<ShalwarMeasurements & KameezMeasurements & PantMeasurements & ShirtMeasurements>;
  notes?: string;
  createdAt: string; // ISO date string (Order Date)
  deliveryDate?: string; // New field (YYYY-MM-DD string)
  isFavorite?: boolean;
  styleChoices?: Record<string, string | boolean | number>; 
}

export interface TailorProfile {
  tailorName: string; // Made non-optional as it's key info
  shopName: string;
  address: string;
  phone: string;
  profileImageBase64: string | null; // Base64 string for the image
}

// Props for components
export interface InputNumericProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  unit?: string;
  placeholder?: string;
  min?: number;
  max?: number;
  step?: number;
}

export interface SelectProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Array<{ value: string; label: string; icon?: React.ReactNode }>;
  placeholder?: string;
}

export interface RadioGroupProps {
  label: string;
  name: string;
  options: Array<{ value: string; label: string; icon?: React.ReactNode }>;
  selectedValue: string;
  onChange: (value: string) => void;
}

export interface ToggleSwitchProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  id: string;
}
