
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useTheme, useLanguage } from './App';
import { APP_CONFIG, orderService, profileService, IconShalwarKameez, IconPantShirt, IconPlus, IconSave, IconChevronRight, IconChevronLeft, IconStarFilled, IconStarOutline, IconDownload, IconWhatsApp, IconProfile, IconCamera, DEFAULT_AVATAR_BASE64, LANG_STRINGS, IconScissors, IconMeasuringTape, IconSewingMachine, IconNeedleThread, IconMannequin } from './dataAndContent';
import { Header, Button, InputNumeric, Select, RadioGroup, ToggleSwitch, LoadingSpinner, OrderCard, PrintableLabelContent, PrintableReceiptContent } from './uiElements';
import { GarmentType, Order, ShalwarMeasurements, KameezMeasurements, Measurement, PantMeasurements, ShirtMeasurements, Theme, TailorProfile, Language } from './types';

declare global {
    interface Window {
        html2canvas: any;
    }
}

const initialMeasurement = (val?: string, lang?: Language): Measurement => ({ value: val || '', unit: lang === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit });

// SectionHeader Component for Forms
const SectionHeader: React.FC<{ title: string; icon?: React.ReactNode }> = ({ title, icon }) => {
  const { language } = useLanguage();
  const iconMargin = language === Language.Urdu ? 'ms-3' : 'me-3';
  return (
    <div className="flex items-center mb-5 pb-3 border-b-2 border-gray-200 dark:border-darkSurfaceElevated">
      {/* Fix: Cast icon to a more specific ReactElement type that accepts className, resolving cloneElement type error. */}
      {icon && <span className={`${iconMargin} text-primary dark:text-primary-light`}>{React.cloneElement(icon as React.ReactElement<{ className?: string }>, { className: 'w-6 h-6' })}</span>}
      <h3 className="text-xl font-semibold text-gray-800 dark:text-darkText">{title}</h3>
    </div>
  );
};


export const HomeScreen: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { strings, language } = useLanguage();
  return (
    <>
      <Header currentTheme={theme} toggleTheme={toggleTheme} title={null} />
      <div className="p-4 sm:p-6 text-center">
        <div className="mb-6 transform transition-transform duration-500 hover:scale-105 inline-block">
          <img 
            src="https://img.icons8.com/external-flaticons-flat-flat-icons/100/external-tailor-professions-men-diversity-flaticons-flat-flat-icons.png" 
            alt="Darzi Master Logo" 
            className="w-28 h-28 mx-auto text-primary dark:text-primary-light" // Increased size
          />
        </div>
        <h2 className="text-4xl font-bold text-gray-800 dark:text-white mb-2 tracking-tight">{strings.appName}</h2>
        <p className="text-lg text-gray-600 dark:text-darkTextSecondary mb-1.5">{strings.appTagline}</p>
        <p className="text-md text-gray-500 dark:text-gray-400 mb-10">{strings.appWelcomeMessage}</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-xl mx-auto mb-10">
          <Link to="/new/shalwar-kameez" className="block transform transition-transform duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 dark:focus:ring-offset-darkBg rounded-xl">
            <Button fullWidth variant="primary" size="lg" className="h-32 text-lg shadow-modern-lg bg-gradient-primary hover:opacity-90">
              <IconShalwarKameez className={`w-10 h-10 ${language === Language.Urdu ? 'ms-3' : 'me-3'}`} />
              {strings.shalwarKameezTailoring}
            </Button>
          </Link>
          <Link to="/new/pant-shirt" className="block transform transition-transform duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 dark:focus:ring-offset-darkBg rounded-xl">
            <Button fullWidth variant="primary" size="lg" className="h-32 text-lg shadow-modern-lg bg-gradient-primary hover:opacity-90">
              <IconPantShirt className={`w-10 h-10 ${language === Language.Urdu ? 'ms-3' : 'me-3'}`} />
              {strings.pantShirtTailoring}
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 max-w-lg mx-auto">
            <Link to="/orders" className="transform transition-transform duration-300 hover:scale-105">
                <Button variant="secondary" fullWidth size="md">{strings.orderHistory}</Button>
            </Link>
            <Link to="/profile" className="transform transition-transform duration-300 hover:scale-105">
                <Button variant="secondary" fullWidth size="md" icon={<IconProfile className="w-5 h-5" />}>{strings.tailorProfile}</Button>
            </Link>
        </div>
      </div>
    </>
  );
};

export const ProfileScreen: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { strings, language } = useLanguage();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [tailorName, setTailorName] = useState('');
  const [shopName, setShopName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [profileImageBase64, setProfileImageBase64] = useState<string | null>(DEFAULT_AVATAR_BASE64);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const loadProfile = async () => {
      setIsLoading(true);
      try {
        const profile = await profileService.getProfile();
        if (profile) {
          setTailorName(profile.tailorName);
          setShopName(profile.shopName);
          setAddress(profile.address);
          setPhone(profile.phone);
          setProfileImageBase64(profile.profileImageBase64 || DEFAULT_AVATAR_BASE64);
        }
      } catch (error) {
        console.error(strings.errorLoadingProfile, error);
        alert(strings.errorLoadingProfile);
      } finally {
        setIsLoading(false);
      }
    };
    loadProfile();
  }, [strings]);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { 
          alert(strings.maxFileSizeError);
          return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImageBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tailorName || !shopName || !phone) {
        alert(language === Language.Urdu ? "درزی کا نام، دکان کا نام، اور فون نمبر ضروری ہیں۔" : "Tailor name, shop name, and phone number are required.");
        return;
    }
    setIsLoading(true);
    const profileData: TailorProfile = {
      tailorName,
      shopName,
      address,
      phone,
      profileImageBase64,
    };
    try {
      await profileService.saveProfile(profileData);
      alert(strings.profileSavedSuccess);
      navigate('/'); 
    } catch (error) {
      console.error(strings.errorSavingProfile, error);
      alert(strings.errorSavingProfile);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading && !tailorName && !shopName) { 
      return (
          <>
              <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={strings.profileScreenTitle} />
              <LoadingSpinner />
          </>
      );
  }

  const placeholderName = language === Language.Urdu ? "مثلاً: محمد علی" : "e.g., Muhammad Ali";
  const placeholderShop = language === Language.Urdu ? "مثلاً: علی گارمنٹس اینڈ ٹیلرز" : "e.g., Ali Garments & Tailors";
  const placeholderAddress = language === Language.Urdu ? "مثلاً: دکان نمبر 5، مین بازار، شہر" : "e.g., Shop No. 5, Main Bazaar, City";
  const placeholderPhone = language === Language.Urdu ? "مثلاً: 03001234567" : "e.g., 03001234567";


  return (
    <>
      <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={strings.profileScreenTitle} />
      <form onSubmit={handleSubmit} className="p-4 space-y-8 max-w-2xl mx-auto">
        <section className="section-card">
          <div className="flex flex-col items-center mb-8">
            <img 
              src={profileImageBase64 || DEFAULT_AVATAR_BASE64} 
              alt={strings.profilePictureLabel} 
              className="w-36 h-36 rounded-full object-cover border-4 border-primary dark:border-primary-light mb-5 shadow-modern-lg"
            />
            <input 
              type="file" 
              accept="image/*" 
              onChange={handleImageChange} 
              ref={fileInputRef}
              className="hidden"
            />
            <Button 
              type="button" 
              variant="secondary" 
              onClick={() => fileInputRef.current?.click()}
              icon={<IconCamera className="w-5 h-5"/>}
              size="sm"
            >
              {strings.uploadImageButton}
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.tailorNameLabel} <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={tailorName}
                onChange={(e) => setTailorName(e.target.value)}
                placeholder={placeholderName}
                required
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.shopNameLabel} <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                placeholder={placeholderShop}
                required
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.addressLabel}</label>
              <textarea 
                  value={address} 
                  onChange={(e) => setAddress(e.target.value)}
                  rows={3}
                  className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"
                  placeholder={placeholderAddress}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.phoneLabel} <span className="text-red-500">*</span></label>
              <input
                type="tel"
                inputMode='tel'
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder={placeholderPhone}
                required
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"
              />
            </div>
          </div>
        </section>
        
        <div className="flex justify-center pt-2">
          <Button type="submit" variant="primary" icon={<IconSave className="w-5 h-5" />} disabled={isLoading} fullWidth size="lg">
            {isLoading ? (strings.save + "...") : strings.save}
          </Button>
        </div>
      </form>
    </>
  );
};


export const ShalwarKameezFormScreen: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { strings, language } = useLanguage();
  const navigate = useNavigate();
  const { orderId } = useParams<{ orderId: string }>();
  const [isLoading, setIsLoading] = useState(false);

  const [orderNumber, setOrderNumber] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [notes, setNotes] = useState('');

  const currentInitialMeasurement = (val?:string) => initialMeasurement(val, language);

  const [waistbandThickness, setWaistbandThickness] = useState(currentInitialMeasurement());
  const [shalwarPocketType, setShalwarPocketType] = useState('side');
  const [bottomHem, setBottomHem] = useState(currentInitialMeasurement());
  const [pajamaStyle, setPajamaStyle] = useState('open');

  const [chest, setChest] = useState(currentInitialMeasurement());
  const [waist, setWaist] = useState(currentInitialMeasurement());
  const [hips, setHips] = useState(currentInitialMeasurement());
  const [shoulder, setShoulder] = useState(currentInitialMeasurement());
  const [sleeveLength, setSleeveLength] = useState(currentInitialMeasurement());
  const [sleeveWidth, setSleeveWidth] = useState(currentInitialMeasurement());
  const [collarSize, setCollarSize] = useState(currentInitialMeasurement());
  const [neckOpening, setNeckOpening] = useState(currentInitialMeasurement());
  const [collarStyle, setCollarStyle] = useState('ban');
  const [frontPocketKameez, setFrontPocketKameez] = useState(true);
  const [frontPocketStyle, setFrontPocketStyle] = useState('single');
  const [sideCut, setSideCut] = useState(true);
  const [cuffStyle, setCuffStyle] = useState('simpleCuff');
  const [cuffThickness, setCuffThickness] = useState(currentInitialMeasurement());
  const [buttonsInCuff, setButtonsInCuff] = useState('2'); 

  useEffect(() => {
    const loadOrder = async () => {
      if (orderId) {
        setIsLoading(true);
        const existingOrder = await orderService.getOrderById(orderId);
        if (existingOrder && existingOrder.garmentType === GarmentType.ShalwarKameez) {
          setOrderNumber(existingOrder.orderNumber);
          setCustomerName(existingOrder.customerName);
          setCustomerMobile(existingOrder.customerMobile || '');
          setDeliveryDate(existingOrder.deliveryDate || '');
          setNotes(existingOrder.notes || '');

          const m = existingOrder.measurements as Partial<ShalwarMeasurements & KameezMeasurements>;
          setWaistbandThickness(m.waistbandThickness || currentInitialMeasurement());
          setShalwarPocketType(m.pocketType || 'side');
          setBottomHem(m.bottomHem || currentInitialMeasurement());
          setPajamaStyle(m.pajamaStyle || 'open');

          setChest(m.chest || currentInitialMeasurement());
          setWaist(m.waist || currentInitialMeasurement());
          setHips(m.hips || currentInitialMeasurement());
          setShoulder(m.shoulder || currentInitialMeasurement());
          setSleeveLength(m.sleeveLength || currentInitialMeasurement());
          setSleeveWidth(m.sleeveWidth || currentInitialMeasurement());
          setCollarSize(m.collarSize || currentInitialMeasurement());
          setNeckOpening(m.neckOpening || currentInitialMeasurement());
          setCuffThickness(m.cuffThickness || currentInitialMeasurement());
          
          const s = existingOrder.styleChoices || {};
          setCollarStyle(s.collarStyle as string || 'ban');
          setFrontPocketKameez(s.frontPocketKameez === undefined ? true : s.frontPocketKameez as boolean);
          setFrontPocketStyle(s.frontPocketStyle as string || 'single');
          setSideCut(s.sideCut === undefined ? true : s.sideCut as boolean);
          setCuffStyle(s.cuffStyle as string || 'simpleCuff');
          setButtonsInCuff(s.buttonsInCuff?.toString() || '2');

        } else if (!existingOrder) {
          console.error("Order not found for editing");
          navigate('/'); 
        }
        setIsLoading(false);
      } else {
        orderService.generateOrderNumber().then(setOrderNumber);
        setCustomerName(''); setCustomerMobile(''); setDeliveryDate(''); setNotes('');
        setWaistbandThickness(currentInitialMeasurement()); setShalwarPocketType('side'); setBottomHem(currentInitialMeasurement()); setPajamaStyle('open');
        setChest(currentInitialMeasurement()); setWaist(currentInitialMeasurement()); setHips(currentInitialMeasurement()); setShoulder(currentInitialMeasurement());
        setSleeveLength(currentInitialMeasurement()); setSleeveWidth(currentInitialMeasurement()); setCollarSize(currentInitialMeasurement()); setNeckOpening(currentInitialMeasurement());
        setCollarStyle('ban'); setFrontPocketKameez(true); setFrontPocketStyle('single'); setSideCut(true);
        setCuffStyle('simpleCuff'); setCuffThickness(currentInitialMeasurement()); setButtonsInCuff('2');
      }
    };
    loadOrder();
  }, [orderId, navigate, language]); // Add language to re-init measurements with correct unit

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const orderData: Order = {
      id: orderId || Date.now().toString(),
      orderNumber,
      customerName,
      customerMobile,
      deliveryDate,
      garmentType: GarmentType.ShalwarKameez,
      measurements: {
        waistbandThickness, bottomHem, chest, waist, hips, shoulder, sleeveLength, sleeveWidth, collarSize, neckOpening, cuffThickness,
        pocketType: shalwarPocketType, pajamaStyle: pajamaStyle,
      },
      styleChoices: {
        collarStyle, frontPocketKameez, frontPocketStyle: frontPocketKameez ? frontPocketStyle : undefined, sideCut, cuffStyle,
        buttonsInCuff: parseInt(buttonsInCuff) || 0,
      },
      notes,
      createdAt: orderId ? (await orderService.getOrderById(orderId))?.createdAt || new Date().toISOString() : new Date().toISOString(),
      isFavorite: orderId ? (await orderService.getOrderById(orderId))?.isFavorite || false : false,
    };

    try {
      await orderService.saveOrder(orderData);
      navigate(`/order/${orderData.id}`);
    } catch (error) {
      console.error("Failed to save order:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  if (isLoading && orderId) { 
    return (
      <>
        <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={`${strings.edit} ${strings.shalwarKameezTailoring}`} />
        <LoadingSpinner />
      </>
    );
  }
  
  const placeholderCustName = language === Language.Urdu ? "مثلاً: اسلم پرویز" : "e.g., Aslam Pervaiz";
  const placeholderCustMobile = language === Language.Urdu ? "مثلاً: 03001234567" : "e.g., 03001234567";
  const placeholderNotes = language === Language.Urdu ? "یہاں اضافی ہدایات یا نوٹس درج کریں۔" : "Enter additional instructions or notes here.";


  return (
    <>
      <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={orderId ? `${strings.edit} ${strings.shalwarKameezTailoring}` : `${strings.newOrder} - ${strings.shalwarKameezTailoring}`} />
      <form onSubmit={handleSubmit} className="p-4 space-y-8">
        <section className="section-card">
          <SectionHeader title={strings.orderDetails} icon={<IconProfile />} />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
             <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.orderNumber}</label>
              <input type="text" value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} placeholder="DM-YYMMDD-XXX" className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.customerName}</label>
              <input type="text" value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder={placeholderCustName} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.customerMobile}</label>
              <input type="tel" inputMode='tel' value={customerMobile} onChange={(e) => setCustomerMobile(e.target.value)} placeholder={placeholderCustMobile} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.deliveryDate}</label>
                <input type="date" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
          </div>
        </section>

        <section className="section-card">
          <SectionHeader title={strings.shalwarDetails} icon={<IconShalwarKameez />} />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
            <InputNumeric label={strings.waistbandThickness} value={waistbandThickness.value} onChange={v => setWaistbandThickness(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <RadioGroup
              label={strings.pocketChoice} name="shalwarPocketType"
              options={[ { value: 'side', label: strings.sidePocket }, { value: 'front', label: strings.frontPocketLabel }, { value: 'none', label: strings.noPocket }]}
              selectedValue={shalwarPocketType} onChange={setShalwarPocketType} />
            <InputNumeric label={strings.bottomHemPancha} value={bottomHem.value} onChange={v => setBottomHem(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <RadioGroup
              label={strings.pajamaStyle} name="pajamaStyle"
              options={[ { value: 'open', label: strings.openStyle }, { value: 'tight', label: strings.tightStyle }]}
              selectedValue={pajamaStyle} onChange={setPajamaStyle} />
          </div>
        </section>

        <section className="section-card">
          <SectionHeader title={strings.kameezDetails} icon={<IconMeasuringTape />} />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
            <InputNumeric label={strings.chest} value={chest.value} onChange={v => setChest(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.waist} value={waist.value} onChange={v => setWaist(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.hips} value={hips.value} onChange={v => setHips(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.shoulder} value={shoulder.value} onChange={v => setShoulder(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.sleeveLength} value={sleeveLength.value} onChange={v => setSleeveLength(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.sleeveWidth} value={sleeveWidth.value} onChange={v => setSleeveWidth(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.collarSize} value={collarSize.value} onChange={v => setCollarSize(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.neckOpening} value={neckOpening.value} onChange={v => setNeckOpening(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <Select label={strings.collarStyle} value={collarStyle} onChange={setCollarStyle}
              options={[
                { value: 'ban', label: strings.collarBanStyle }, { value: 'collar', label: strings.collarRegularStyle },
                { value: 'round', label: strings.roundNeckStyle }, { value: 'v-neck', label: strings.vNeckStyle },
                { value: 'sherwani', label: strings.sherwaniStyle },
              ]} />
            <ToggleSwitch id="frontPocketKameez" label={strings.frontPocketKameez} checked={frontPocketKameez} onChange={setFrontPocketKameez} />
            {frontPocketKameez && (
              <Select label={strings.pocketChoice} value={frontPocketStyle} onChange={setFrontPocketStyle}
                options={[
                  { value: 'single', label: strings.singlePocket }, { value: 'double', label: strings.doublePocket },
                  { value: 'straight', label: strings.straightPocket }, { value: 'angled', label: strings.angledPocket },
                ]} />
            )}
            <ToggleSwitch id="sideCut" label={strings.sideCut} checked={sideCut} onChange={setSideCut} />
            <Select label={strings.cuffStyle} value={cuffStyle} onChange={setCuffStyle}
              options={[
                { value: 'simpleCuff', label: strings.simpleCuff }, { value: 'roundCuff', label: strings.roundCuff },
                { value: 'squareCuff', label: strings.squareCuff }, { value: 'pointedCuff', label: strings.pointedCuff },
              ]} />
            <InputNumeric label={strings.cuffThickness} value={cuffThickness.value} onChange={v => setCuffThickness(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.buttonsInCuff}</label>
              <input type="number" inputMode="numeric" value={buttonsInCuff} onChange={(e) => setButtonsInCuff(e.target.value)} placeholder={language === Language.Urdu ? "مثلاً: ۲":"e.g., 2"} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
          </div>
        </section>

        <section className="section-card">
            <SectionHeader title={strings.notes} icon={<IconNeedleThread />} />
            <textarea 
                value={notes} 
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"
                placeholder={placeholderNotes}
            />
        </section>
        
        <div className={`flex pt-2 ${language === Language.Urdu ? 'justify-start' : 'justify-end'}`}>
          <Button type="submit" variant="primary" icon={<IconSave className="w-5 h-5" />} disabled={isLoading} size="lg">
            {isLoading ? (strings.save + "...") : strings.save}
          </Button>
        </div>
      </form>
    </>
  );
};


export const PantShirtFormScreen: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { strings, language } = useLanguage();
  const navigate = useNavigate();
  const { orderId } = useParams<{ orderId: string }>();
  const [isLoading, setIsLoading] = useState(false);

  const [orderNumber, setOrderNumber] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [notes, setNotes] = useState('');
  
  const currentInitialMeasurement = (val?:string) => initialMeasurement(val, language);

  const [pantWaist, setPantWaist] = useState(currentInitialMeasurement());
  const [pantHip, setPantHip] = useState(currentInitialMeasurement());
  const [pantThigh, setPantThigh] = useState(currentInitialMeasurement());
  const [pantLength, setPantLength] = useState(currentInitialMeasurement());
  const [pantFrontPockets, setPantFrontPockets] = useState('2');
  const [pantBackPockets, setPantBackPockets] = useState('2');
  const [pantBeltLoops, setPantBeltLoops] = useState('5');
  const [pantClosureType, setPantClosureType] = useState('zip');
  const [pantBottomStyle, setPantBottomStyle] = useState('folded');

  const [shirtCollar, setShirtCollar] = useState(currentInitialMeasurement());
  const [shirtCuff, setShirtCuff] = useState(currentInitialMeasurement());
  const [shirtShoulder, setShirtShoulder] = useState(currentInitialMeasurement());
  const [shirtChest, setShirtChest] = useState(currentInitialMeasurement());
  const [shirtSleeveLength, setShirtSleeveLength] = useState(currentInitialMeasurement());
  const [shirtSleeveWidth, setShirtSleeveWidth] = useState(currentInitialMeasurement());
  const [shirtFrontButtonOption, setShirtFrontButtonOption] = useState('full');
  const [shirtPocketOption, setShirtPocketOption] = useState('one');
  const [shirtSideCut, setShirtSideCut] = useState(false); 

  useEffect(() => {
    const loadOrder = async () => {
      if (orderId) {
        setIsLoading(true);
        const existingOrder = await orderService.getOrderById(orderId);
        if (existingOrder && existingOrder.garmentType === GarmentType.PantShirt) {
          setOrderNumber(existingOrder.orderNumber);
          setCustomerName(existingOrder.customerName);
          setCustomerMobile(existingOrder.customerMobile || '');
          setDeliveryDate(existingOrder.deliveryDate || '');
          setNotes(existingOrder.notes || '');

          const m = existingOrder.measurements as Partial<PantMeasurements & ShirtMeasurements>;
          setPantWaist(m.waist || currentInitialMeasurement()); 
          setPantHip(m.hip || currentInitialMeasurement());
          setPantThigh(m.thigh || currentInitialMeasurement());
          setPantLength(m.length || currentInitialMeasurement());
          setShirtCollar(m.collar || currentInitialMeasurement());
          setShirtCuff(m.cuff || currentInitialMeasurement());
          setShirtShoulder(m.shoulder || currentInitialMeasurement());
          setShirtChest(m.chest || currentInitialMeasurement());
          setShirtSleeveLength(m.sleeveLength || currentInitialMeasurement());
          setShirtSleeveWidth(m.sleeveWidth || currentInitialMeasurement());

          const s = existingOrder.styleChoices || {};
          setPantFrontPockets(s.frontPockets?.toString() || '2');
          setPantBackPockets(s.backPockets?.toString() || '2');
          setPantBeltLoops(s.beltLoops?.toString() || '5');
          setPantClosureType(s.closureType as string || 'zip');
          setPantBottomStyle(s.pantBottomStyle as string || 'folded');
          setShirtFrontButtonOption(s.frontButtonOption as string || 'full');
          setShirtPocketOption(s.pocketOption as string || 'one');
          setShirtSideCut(s.shirtSideCut === undefined ? false : s.shirtSideCut as boolean);

        } else if(!existingOrder) {
            console.error("Order not found for editing");
            navigate('/');
        }
        setIsLoading(false);
      } else {
        orderService.generateOrderNumber().then(setOrderNumber);
        setCustomerName(''); setCustomerMobile(''); setDeliveryDate(''); setNotes('');
        setPantWaist(currentInitialMeasurement()); setPantHip(currentInitialMeasurement()); setPantThigh(currentInitialMeasurement()); setPantLength(currentInitialMeasurement());
        setPantFrontPockets('2'); setPantBackPockets('2'); setPantBeltLoops('5'); setPantClosureType('zip'); setPantBottomStyle('folded');
        setShirtCollar(currentInitialMeasurement()); setShirtCuff(currentInitialMeasurement()); setShirtShoulder(currentInitialMeasurement()); setShirtChest(currentInitialMeasurement());
        setShirtSleeveLength(currentInitialMeasurement()); setShirtSleeveWidth(currentInitialMeasurement());
        setShirtFrontButtonOption('full'); setShirtPocketOption('one'); setShirtSideCut(false);
      }
    };
    loadOrder();
  }, [orderId, navigate, language]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const measurements: Partial<PantMeasurements & ShirtMeasurements> = {
      waist: pantWaist, hip: pantHip, thigh: pantThigh, length: pantLength, collar: shirtCollar, cuff: shirtCuff,
      shoulder: shirtShoulder, chest: shirtChest, sleeveLength: shirtSleeveLength, sleeveWidth: shirtSleeveWidth,   
    };
    const styleChoices: Record<string, string | boolean | number> = {
      frontPockets: parseInt(pantFrontPockets) || 0, backPockets: parseInt(pantBackPockets) || 0, beltLoops: parseInt(pantBeltLoops) || 0,
      closureType: pantClosureType, pantBottomStyle: pantBottomStyle, frontButtonOption: shirtFrontButtonOption,
      pocketOption: shirtPocketOption, shirtSideCut: shirtSideCut,
    };
    const orderData: Order = {
      id: orderId || Date.now().toString(), orderNumber, customerName, customerMobile, deliveryDate, garmentType: GarmentType.PantShirt,
      measurements, styleChoices, notes,
      createdAt: orderId ? (await orderService.getOrderById(orderId))?.createdAt || new Date().toISOString() : new Date().toISOString(),
      isFavorite: orderId ? (await orderService.getOrderById(orderId))?.isFavorite || false : false,
    };
    try {
      await orderService.saveOrder(orderData);
      navigate(`/order/${orderData.id}`);
    } catch (error) {
      console.error("Failed to save Pant Shirt order:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading && orderId) {
    return (
      <>
        <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={`${strings.edit} ${strings.pantShirtTailoring}`} />
        <LoadingSpinner />
      </>
    );
  }
  
  const placeholderCustName = language === Language.Urdu ? "مثلاً: جاوید اقبال" : "e.g., Javed Iqbal";
  const placeholderCustMobile = language === Language.Urdu ? "مثلاً: 03001234567" : "e.g., 03001234567";
  const placeholderNotes = language === Language.Urdu ? "یہاں اضافی ہدایات یا نوٹس درج کریں۔" : "Enter additional instructions or notes here.";
  const placeholderNumber = language === Language.Urdu ? "مثلاً: ۲" : "e.g., 2";


  return (
    <>
      <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={orderId ? `${strings.edit} ${strings.pantShirtTailoring}` : `${strings.newOrder} - ${strings.pantShirtTailoring}`} />
      <form onSubmit={handleSubmit} className="p-4 space-y-8">
        <section className="section-card">
          <SectionHeader title={strings.orderDetails} icon={<IconProfile />} />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
             <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.orderNumber}</label>
              <input type="text" value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} placeholder="DM-YYMMDD-XXX" className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.customerName}</label>
              <input type="text" value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder={placeholderCustName} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.customerMobile}</label>
              <input type="tel" inputMode='tel' value={customerMobile} onChange={(e) => setCustomerMobile(e.target.value)} placeholder={placeholderCustMobile} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.deliveryDate}</label>
                <input type="date" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
          </div>
        </section>

        <section className="section-card">
          <SectionHeader title={strings.pantDetails} icon={<IconPantShirt />} />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
            <InputNumeric label={strings.pantWaist} value={pantWaist.value} onChange={v => setPantWaist(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.pantHip} value={pantHip.value} onChange={v => setPantHip(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.pantThigh} value={pantThigh.value} onChange={v => setPantThigh(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.pantLength} value={pantLength.value} onChange={v => setPantLength(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.frontPocketsPant}</label>
                <input type="number" inputMode="numeric" value={pantFrontPockets} onChange={(e) => setPantFrontPockets(e.target.value)} placeholder={placeholderNumber} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.backPocketsPant}</label>
                <input type="number" inputMode="numeric" value={pantBackPockets} onChange={(e) => setPantBackPockets(e.target.value)} placeholder={placeholderNumber} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-darkTextSecondary mb-1.5">{strings.beltLoops}</label>
                <input type="number" inputMode="numeric" value={pantBeltLoops} onChange={(e) => setPantBeltLoops(e.target.value)} placeholder={placeholderNumber} className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"/>
            </div>
             <RadioGroup label={strings.closureType} name="pantClosureType"
              options={[ { value: 'zip', label: strings.zipOption }, { value: 'button', label: strings.buttonOption }]}
              selectedValue={pantClosureType} onChange={setPantClosureType} />
            <RadioGroup label={language === Language.Urdu ? "نچلا حصہ" : "Bottom Style"} name="pantBottomStyle"
              options={[ { value: 'folded', label: strings.pantBottomFolded }, { value: 'simple', label: strings.pantBottomSimple }]}
              selectedValue={pantBottomStyle} onChange={setPantBottomStyle} />
          </div>
        </section>

        <section className="section-card">
          <SectionHeader title={strings.shirtDetails} icon={<IconMeasuringTape />} />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-5">
            <InputNumeric label={strings.shirtCollar} value={shirtCollar.value} onChange={v => setShirtCollar(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.shirtCuff} value={shirtCuff.value} onChange={v => setShirtCuff(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.shirtShoulder} value={shirtShoulder.value} onChange={v => setShirtShoulder(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.shirtChest} value={shirtChest.value} onChange={v => setShirtChest(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.shirtSleeveLength} value={shirtSleeveLength.value} onChange={v => setShirtSleeveLength(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <InputNumeric label={strings.shirtSleeveWidth} value={shirtSleeveWidth.value} onChange={v => setShirtSleeveWidth(currentInitialMeasurement(v))} unit={language === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit} />
            <RadioGroup label={strings.placketFrontOpening} name="shirtFrontButtonOption"
              options={[
                { value: 'full', label: strings.shirtFrontButtonFull }, { value: 'half', label: strings.shirtFrontButtonHalf },
                { value: 'none', label: strings.shirtFrontButtonNone },
              ]} selectedValue={shirtFrontButtonOption} onChange={setShirtFrontButtonOption} />
            <RadioGroup label={strings.pocketChoice} name="shirtPocketOption"
              options={[
                { value: 'one', label: strings.shirtPocketOne }, { value: 'two', label: strings.shirtPocketTwo },
                { value: 'none', label: strings.shirtPocketNone },
              ]} selectedValue={shirtPocketOption} onChange={setShirtPocketOption} />
            <ToggleSwitch id="shirtSideCut" label={strings.sideCut} checked={shirtSideCut} onChange={setShirtSideCut} />
          </div>
        </section>
        
        <section className="section-card">
            <SectionHeader title={strings.notes} icon={<IconNeedleThread />} />
            <textarea 
                value={notes} 
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring"
                placeholder={placeholderNotes}
            />
        </section>

        <div className={`flex pt-2 ${language === Language.Urdu ? 'justify-start' : 'justify-end'}`}>
          <Button type="submit" variant="primary" icon={<IconSave className="w-5 h-5" />} disabled={isLoading} size="lg">
            {isLoading ? (strings.save + "...") : strings.save}
          </Button>
        </div>
      </form>
    </>
  );
};


export const OrderListScreen: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { strings, language } = useLanguage();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchOrders = useCallback(async () => {
    setIsLoading(true);
    const fetchedOrders = await orderService.getOrders();
    fetchedOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    setOrders(fetchedOrders);
    setFilteredOrders(fetchedOrders);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  useEffect(() => {
    const lowerSearchTerm = searchTerm.toLowerCase().trim();
    if (!lowerSearchTerm) {
      setFilteredOrders(orders);
      return;
    }
    const result = orders.filter(order => 
      order.orderNumber.toLowerCase().includes(lowerSearchTerm) ||
      order.customerName.toLowerCase().includes(lowerSearchTerm) ||
      (order.customerMobile && order.customerMobile.includes(searchTerm.trim())) 
    );
    setFilteredOrders(result);
  }, [searchTerm, orders]);

  const handleToggleFavorite = async (id: string, isFavorite: boolean) => {
    const order = orders.find(o => o.id === id);
    if (order) {
      const updatedOrder = { ...order, isFavorite };
      await orderService.saveOrder(updatedOrder);
      // Optimistically update UI then fetch to ensure consistency
      setOrders(prevOrders => prevOrders.map(o => o.id === id ? updatedOrder : o));
      setFilteredOrders(prevFiltered => prevFiltered.map(o => o.id === id ? updatedOrder : o));
      // Optionally re-fetch if needed, but optimistic update is faster for UI
      // fetchOrders(); 
    }
  };

  return (
    <>
      <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={strings.orderHistory} />
      <div className="p-4">
        <div className="mb-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <input 
            type="text"
            placeholder={strings.searchPlaceholder}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full sm:flex-grow p-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-gray-50 dark:bg-darkSurface text-gray-900 dark:text-white input-focus-ring shadow-modern-sm"
          />
          <Link to="/" className="w-full sm:w-auto"> 
            {/* Fix: Remove invalid 'sm:fullWidth' prop. Responsive width is handled by the parent Link's Tailwind classes. */}
            <Button variant="primary" icon={<IconPlus className="w-5 h-5" />} fullWidth>
              {strings.newOrder}
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <LoadingSpinner />
        ) : filteredOrders.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredOrders.map(order => (
              <OrderCard 
                key={order.id} 
                order={order} 
                onClick={() => navigate(`/order/${order.id}`)}
                onToggleFavorite={handleToggleFavorite}
              />
            ))}
          </div>
        ) : (
          <div className="text-center text-gray-500 dark:text-darkTextSecondary py-16">
            <IconSewingMachine className="w-20 h-20 mx-auto mb-4 opacity-50" />
            <p className="text-xl">{strings.noOrdersFound}</p>
            {orders.length > 0 && searchTerm && <p className="text-sm mt-2">{language === Language.Urdu ? "اپنی تلاش کو بہتر بنانے کی کوشش کریں۔" : "Try refining your search."}</p>}
          </div>
        )}
      </div>
    </>
  );
};

export const getDisplayKey = (key: string, currentStrings: typeof LANG_STRINGS[Language.Urdu]): string => {
    const specificLabel = (currentStrings as any)[key];
    if (specificLabel) return specificLabel;
    
    const styleKeyMappings: Record<string, keyof typeof LANG_STRINGS[Language.Urdu]> = {
        'ban': 'collarBanStyle', 'collar': 'collarRegularStyle', 'round': 'roundNeckStyle', 'v-neck': 'vNeckStyle', 'sherwani': 'sherwaniStyle',
        'simpleCuff': 'simpleCuff', 'roundCuff': 'roundCuff', 'squareCuff': 'squareCuff', 'pointedCuff': 'pointedCuff',
        'side': 'sidePocket', 'front': 'frontPocketLabel', 'none': 'noPocket', 
        'open': 'openStyle', 'tight': 'tightStyle', 
        'single': 'singlePocket', 'double': 'doublePocket', 'straight': 'straightPocket', 'angled': 'angledPocket',
        'folded': 'pantBottomFolded', 'simple': 'pantBottomSimple',
        'zip': 'zipOption', 'button': 'buttonOption',
        'full': 'shirtFrontButtonFull', 'half': 'shirtFrontButtonHalf', // 'none' is already 'noPocket' essentially for shirt
        'one': 'shirtPocketOne', 'two': 'shirtPocketTwo', // 'none' is 'noPocket'
    };
    if (styleKeyMappings[key] && (currentStrings as any)[styleKeyMappings[key]]) {
        return (currentStrings as any)[styleKeyMappings[key]];
    }
    
    // Improved fallback: try to match camelCase keys if not directly found
    const camelCaseKey = key.charAt(0).toLowerCase() + key.slice(1).replace(/([A-Z])/g, letter => `${letter}`);
    const potentialLabel = (currentStrings as any)[camelCaseKey] || (currentStrings as any)[key.toLowerCase()];
    if (potentialLabel) return potentialLabel;

    // Final fallback: simple capitalization
    let titleCaseKey = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()).trim();
    return titleCaseKey;
};

export const getDisplayValue = (key: string, value: any, currentLanguage: Language, currentStrings?: typeof LANG_STRINGS[Language.Urdu]): string => {
  const s = currentStrings || LANG_STRINGS[currentLanguage]; 
  if (value === null || value === undefined || value === '') return '-';
  
  if (typeof value === 'boolean') {
      return value ? s.yes : s.no;
  }
  // Check if the value itself is a key in strings (e.g., for enum-like style choices)
  const specificLabelForValue = (s as any)[value.toString()];
  if (specificLabelForValue && typeof specificLabelForValue === 'string') {
      return specificLabelForValue;
  }
  if (typeof value === 'object' && Object.prototype.hasOwnProperty.call(value, 'value') && Object.prototype.hasOwnProperty.call(value, 'unit')) {
    const measurement = value as Measurement;
    if (measurement.value === '' || measurement.value === null || measurement.value === undefined) return '-';
    const unitLabel = measurement.unit || (currentLanguage === Language.Urdu ? APP_CONFIG.defaultUrduUnit : APP_CONFIG.defaultUnit);
    // Format number for current language if possible (e.g. Urdu numerals)
    const numericValue = parseFloat(measurement.value);
    const displayNum = isNaN(numericValue) ? measurement.value : numericValue.toLocaleString(currentLanguage === Language.Urdu ? 'ur-PK' : 'en-US');
    return `${displayNum} ${unitLabel}`;
  }
  return String(value);
};

// UniqueReceiptCard (Revamped for Modern Look)
const UniqueReceiptCard: React.FC<{ order: Order, tailorProfile: TailorProfile | null, innerRef: React.RefObject<HTMLDivElement> }> = ({ order, tailorProfile, innerRef }) => {
    const { strings, language } = useLanguage();
    const dir = language === Language.Urdu ? 'rtl' : 'ltr';
    const dateLocale = language === Language.Urdu ? 'ur-PK' : 'en-US';
    const font = language === Language.Urdu ? '"Jameel Noori Nastaleeq", "Noto Nastaliq Urdu", sans-serif' : '"Inter", sans-serif';


    const currentShopName = tailorProfile?.shopName || strings.shopName;
    const currentTailorName = tailorProfile?.tailorName;
    const currentShopContact = tailorProfile?.phone || APP_CONFIG.developerContact;
    const currentShopAddress = tailorProfile?.address;

    return (
        <div ref={innerRef} dir={dir} className="bg-white dark:bg-darkSurface text-gray-800 dark:text-darkText p-5 shadow-modern-xl rounded-xl mx-auto my-5 border border-gray-200 dark:border-darkSurfaceElevated" style={{ width: '380px', fontFamily: font }}>
            {/* Header Section */}
            <div className="text-center mb-5 pb-4 border-b-2 border-gray-300 dark:border-gray-600">
                <h2 className="text-2xl font-bold text-primary dark:text-primary-light mb-1.5 tracking-tight">{currentShopName}</h2>
                {currentTailorName && <p className="text-lg font-medium text-gray-700 dark:text-gray-300">{currentTailorName}</p>}
                {currentShopAddress && <p className="text-xs text-gray-500 dark:text-gray-400 mt-1.5">{currentShopAddress}</p>}
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{strings.phoneLabel}: {currentShopContact}</p>
                <p className="text-md text-gray-500 dark:text-gray-400 mt-2.5 font-semibold uppercase tracking-wider">{strings.receipt}</p>
            </div>

            {/* Order & Customer Info */}
            <div className="mb-5 space-y-1.5 text-sm">
                <div className="flex justify-between items-center">
                    <span className="font-semibold">{strings.orderNumber}: <span className="font-normal">{order.orderNumber}</span></span> 
                    <span className="text-xs text-gray-500 dark:text-darkTextSecondary">{new Date(order.createdAt).toLocaleDateString(dateLocale, { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                </div>
                <p><strong className="font-semibold">{strings.customerName}:</strong> {order.customerName}</p>
                {order.customerMobile && <p><strong className="font-semibold">{strings.customerMobile}:</strong> {order.customerMobile}</p>}
                {order.deliveryDate && <p><strong className="font-semibold">{strings.deliveryDate}:</strong> {new Date(order.deliveryDate).toLocaleDateString(dateLocale, {  year: 'numeric', month: 'long', day: 'numeric' })}</p>}
                <p><strong className="font-semibold">{strings.garmentType}:</strong> {order.garmentType === GarmentType.ShalwarKameez ? strings.shalwarKameezTailoring : strings.pantShirtTailoring}</p>
            </div>

            {/* Measurements & Style Choices */}
            {(Object.keys(order.measurements).length > 0 || (order.styleChoices && Object.keys(order.styleChoices).filter(k=>order.styleChoices && order.styleChoices[k] !== false).length > 0)) && (
                 <div className="my-5 py-4 border-t border-b border-gray-200 dark:border-gray-600">
                    <h4 className="font-semibold text-md mb-2.5 text-gray-700 dark:text-darkTextSecondary">{strings.measurements} / {strings.styleChoices}:</h4>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs leading-relaxed">
                        {Object.entries(order.measurements).map(([key, val]) => {
                             const displayVal = getDisplayValue(key, val, language, strings);
                             if (displayVal !== '-' && displayVal !== strings.no) {
                                return <div key={`m-${key}`} className="truncate"><strong className="font-medium text-gray-600 dark:text-gray-400">{getDisplayKey(key, strings)}:</strong> {displayVal}</div>;
                            }
                            return null;
                        })}
                        {order.styleChoices && Object.entries(order.styleChoices).filter(([, value]) => value !== undefined && value !== null && value !== '' && value !== false).map(([key, value]) => (
                            <div key={`s-${key}`} className="truncate"><strong className="font-medium text-gray-600 dark:text-gray-400">{getDisplayKey(key, strings)}:</strong> {getDisplayValue(key, value, language, strings)}</div>
                        ))}
                    </div>
                </div>
            )}

            {/* Notes */}
            {order.notes && (
                <div className="my-5">
                    <h4 className="font-semibold text-md mb-1.5 text-gray-700 dark:text-darkTextSecondary">{strings.notes}:</h4>
                    <p className="text-xs whitespace-pre-wrap p-2.5 bg-gray-50 dark:bg-darkSurfaceElevated rounded-md border border-gray-200 dark:border-gray-600 leading-normal">{order.notes}</p>
                </div>
            )}

            {/* Footer */}
            <div className="mt-6 pt-4 border-t-2 border-gray-300 dark:border-gray-600 text-center">
                <p className="text-sm font-semibold text-gray-700 dark:text-darkTextSecondary">{strings.thankYouVisitAgain}</p>
                <p className="text-xs mt-2.5 text-gray-400 dark:text-gray-500">{APP_CONFIG.copyrightText}</p>
            </div>
        </div>
    );
};


export const OrderDetailScreen: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { strings, language } = useLanguage();
  const navigate = useNavigate();
  const { orderId } = useParams<{ orderId: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [tailorProfile, setTailorProfile] = useState<TailorProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [receiptImageData, setReceiptImageData] = useState<string | null>(null);
  const [isProcessingImage, setIsProcessingImage] = useState(false);

  const uniqueReceiptRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchOrderAndProfile = async () => {
      if (!orderId) {
        navigate('/');
        return;
      }
      setIsLoading(true);
      try {
        const fetchedOrder = await orderService.getOrderById(orderId);
        const fetchedProfile = await profileService.getProfile();
        
        if (fetchedOrder) {
          setOrder(fetchedOrder);
        } else {
          console.error("Order not found");
          navigate('/orders');
        }
        setTailorProfile(fetchedProfile);
      } catch (error) {
        console.error("Error fetching order details or profile:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchOrderAndProfile();
  }, [orderId, navigate]);

  const handlePrintContent = async (contentElement: React.ReactElement) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      const direction = language === Language.Urdu ? 'rtl' : 'ltr';
      // Use the Inter font as primary for print, Jameel as secondary for Urdu
      const fontFamily = language === Language.Urdu ? "'Jameel Noori Nastaleeq', 'Noto Nastaliq Urdu', 'Inter', sans-serif" : "'Inter', 'Roboto', sans-serif";
      
      printWindow.document.write(`<html><head><title>${strings.printReceipt || 'Print'}</title>`);
      printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>'); // Tailwind for print
      printWindow.document.write('<link rel="preconnect" href="https://fonts.googleapis.com">');
      printWindow.document.write('<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>');
      printWindow.document.write('<link href="https://fonts.googleapis.com/css2?family=Jameel+Noori+Nastaleeq&family=Noto+Nastaliq+Urdu:wght@400;700&family=Inter:wght@400;500;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">');
      printWindow.document.write(`<style>body { font-family: ${fontFamily}; direction: ${direction}; -webkit-print-color-adjust: exact; print-color-adjust: exact; } @page { size: A4; margin: 15mm; } .print-only { display: block !important; } .no-print { display: none !important; } </style>`);
      printWindow.document.write('</head><body class="bg-white text-black">'); // Ensure bg and text for print
      
      const tempDiv = document.createElement('div');
      const ReactDOMServer = await import('react-dom/server');
      tempDiv.innerHTML = ReactDOMServer.renderToString(contentElement);
      printWindow.document.write(tempDiv.innerHTML);
      printWindow.document.write('</body></html>');
      printWindow.document.close();
      
      // Wait for styles to load before printing
      printWindow.onload = () => {
        setTimeout(() => { // Additional small delay can help ensure rendering
            printWindow.focus();
            printWindow.print();
        }, 200);
      };
    }
  };

  const handlePrintLabel = () => {
    if (!order) return;
    handlePrintContent(<PrintableLabelContent />); 
  };

  const handlePrintReceipt = () => {
    if (!order) return;
    handlePrintContent(<PrintableReceiptContent order={order} tailorProfile={tailorProfile} />);
  };
  
  const handleDeleteOrder = async () => {
    if (!order) return;
    const confirmDelete = window.confirm(`${strings.deleteConfirmation} ${order.orderNumber} (${order.customerName}) ${strings.deleteConfirmationPrompt}`);
    if (confirmDelete) {
      await orderService.deleteOrder(order.id);
      navigate('/orders');
    }
  };

  const handleToggleFavorite = async () => {
    if (!order) return;
    const updatedOrder = { ...order, isFavorite: !order.isFavorite };
    await orderService.saveOrder(updatedOrder);
    setOrder(updatedOrder);
  };

  const handleSaveReceiptAsImage = async () => {
    if (!uniqueReceiptRef.current || !window.html2canvas) return;
    setIsProcessingImage(true);
    try {
        const canvas = await window.html2canvas(uniqueReceiptRef.current, {
            scale: 3, // Increased scale for better quality
            useCORS: true,
            backgroundColor: theme === Theme.Dark ? '#1f2937' /* darkSurface */ : '#ffffff', 
            logging: false, // reduce console noise
        });
        const dataUrl = canvas.toDataURL('image/png', 0.95); // Slightly better compression
        setReceiptImageData(dataUrl);

        const link = document.createElement('a');
        link.download = `receipt-${order?.orderNumber || 'darzi-master'}.png`;
        link.href = dataUrl;
        document.body.appendChild(link); // Required for Firefox
        link.click();
        document.body.removeChild(link);
        alert(strings.receiptImageSaved);

    } catch (error) {
        console.error('Error generating image:', error);
        alert((language === Language.Urdu ? 'تصویر بنانے میں خرابی: ' : 'Error generating image: ') + error);
    } finally {
        setIsProcessingImage(false);
    }
  };

  const handleShareToWhatsApp = async () => {
    if (!order || !receiptImageData) return;
    
    const currentShopName = tailorProfile?.shopName || strings.shopName;
    const message = `${strings.whatsappShareMessage}${order.orderNumber}\n${strings.customerName}: ${order.customerName}\n${currentShopName}`;
    
    try {
        const response = await fetch(receiptImageData);
        const blob = await response.blob();
        const file = new File([blob], `receipt-${order.orderNumber}.png`, { type: 'image/png' });

        if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({
                title: `${strings.receipt} - ${order.orderNumber}`,
                text: message,
                files: [file],
            });
            // alert(strings.receiptImageShared); // Commented out as share dialog handles feedback
        } else {
            const fallbackMessage = language === Language.Urdu ? "براہ کرم اوپر محفوظ کردہ تصویر منسلک کریں۔" : "Please attach the image saved above.";
            const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message + "\n\n" + fallbackMessage)}`;
            window.open(whatsappUrl, '_blank');
        }
    } catch (error) {
        console.error('Error sharing to WhatsApp:', error);
        const errorMessage = language === Language.Urdu ? "تصویر شیئر کرنے میں خرابی۔ براہ کرم اوپر محفوظ کردہ تصویر دستی طور پر منسلک کریں۔" : "Error sharing image. Please manually attach the image saved above.";
        const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message + "\n\n" + errorMessage)}`;
        window.open(whatsappUrl, '_blank');
    }
  };


  if (isLoading) {
    return (
      <>
        <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={strings.orderDetails} />
        <LoadingSpinner />
      </>
    );
  }

  if (!order) {
    return (
      <>
        <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={strings.orderDetails} />
        <p className="text-center text-red-500 p-10">{strings.noOrdersFound}</p>
      </>
    );
  }

  const garmentTypeLabel = order.garmentType === GarmentType.ShalwarKameez ? strings.shalwarKameezTailoring : strings.pantShirtTailoring;
  const editPath = order.garmentType === GarmentType.ShalwarKameez ? `/edit/shalwar-kameez/${order.id}` : `/edit/pant-shirt/${order.id}`;
  const dateLocale = language === Language.Urdu ? 'ur-PK' : 'en-US';

  return (
    <>
      <Header currentTheme={theme} toggleTheme={toggleTheme} showBackButton title={`${strings.orderDetails} - ${order.orderNumber}`} />
      <div className="p-4 space-y-8">
        <section className="section-card">
          <div className="flex justify-between items-start mb-5">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-primary dark:text-primary-light tracking-tight">{order.customerName}</h2>
              <p className="text-gray-600 dark:text-darkTextSecondary text-sm">{order.orderNumber}</p>
            </div>
            <button onClick={handleToggleFavorite} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-darkSurfaceElevated transition-colors -mt-1 -mr-1">
              {order.isFavorite ? <IconStarFilled className="w-7 h-7 text-yellow-400 dark:text-yellow-500" /> : <IconStarOutline className="w-7 h-7 text-gray-400 dark:text-gray-500 hover:text-yellow-400" />}
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 text-sm">
            <p><strong className="font-medium text-gray-700 dark:text-darkTextSecondary">{strings.customerMobile}:</strong> {order.customerMobile || '-'}</p>
            <p><strong className="font-medium text-gray-700 dark:text-darkTextSecondary">{strings.garmentType}:</strong> {garmentTypeLabel}</p>
            <p><strong className="font-medium text-gray-700 dark:text-darkTextSecondary">{strings.orderDate}:</strong> {new Date(order.createdAt).toLocaleDateString(dateLocale, { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
            <p><strong className="font-medium text-gray-700 dark:text-darkTextSecondary">{strings.deliveryDate}:</strong> {order.deliveryDate ? new Date(order.deliveryDate).toLocaleDateString(dateLocale, { year: 'numeric', month: 'long', day: 'numeric' }) : '-'}</p>
          </div>
        </section>

        <section className="section-card">
          <SectionHeader title={strings.measurements} icon={<IconMeasuringTape />} />
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-4 text-sm">
            {Object.entries(order.measurements).map(([key, value]) => {
                const displayVal = getDisplayValue(key, value, language, strings);
                if (displayVal === '-' || displayVal === strings.no) return null;
                return <p key={`m-${key}`}><strong className="font-medium text-gray-700 dark:text-darkTextSecondary">{getDisplayKey(key, strings)}:</strong> {displayVal}</p>;
            })}
          </div>
        </section>

        {order.styleChoices && Object.keys(order.styleChoices).filter(k => order.styleChoices && order.styleChoices[k] !== undefined && order.styleChoices[k] !== null && order.styleChoices[k] !== '' && (typeof order.styleChoices[k] !== 'boolean' || order.styleChoices[k] === true) ).length > 0 && (
          <section className="section-card">
            <SectionHeader title={strings.styleChoices} icon={<IconScissors />} />
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-4 text-sm">
              {Object.entries(order.styleChoices).map(([key, value]) => {
                if (value === undefined || value === null || value === '' || (typeof value === 'boolean' && !value)) return null;
                return <p key={`s-${key}`}><strong className="font-medium text-gray-700 dark:text-darkTextSecondary">{getDisplayKey(key, strings)}:</strong> {getDisplayValue(key, value, language, strings)}</p>;
              })}
            </div>
          </section>
        )}

        {order.notes && (
          <section className="section-card">
            <SectionHeader title={strings.notes} icon={<IconNeedleThread />} />
            <p className="text-sm whitespace-pre-wrap bg-gray-50 dark:bg-darkSurfaceElevated p-4 rounded-lg leading-relaxed">{order.notes}</p>
          </section>
        )}
        
        <section className="section-card">
            <SectionHeader title={strings.uniqueReceiptShare} icon={<IconWhatsApp />} />
            <UniqueReceiptCard order={order} tailorProfile={tailorProfile} innerRef={uniqueReceiptRef} />
             <div className="mt-6 flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                    onClick={handleSaveReceiptAsImage} 
                    variant="secondary" 
                    icon={<IconDownload className="w-5 h-5" />}
                    disabled={isProcessingImage}
                    size="md"
                >
                    {isProcessingImage ? (strings.saveReceiptImage + "...") : strings.saveReceiptImage}
                </Button>
                <Button 
                    onClick={handleShareToWhatsApp} 
                    variant="accent"
                    className={`${!receiptImageData ? 'opacity-50 cursor-not-allowed' : ''}`}
                    icon={<IconWhatsApp className="w-5 h-5" />}
                    disabled={!receiptImageData || isProcessingImage}
                    size="md"
                >
                    {strings.shareToWhatsApp}
                </Button>
            </div>
        </section>

        <section className="mt-10 p-5 bg-gray-100 dark:bg-darkSurfaceElevated rounded-xl shadow-modern-inner print:hidden">
          <h3 className="text-lg font-semibold mb-5 text-center text-gray-700 dark:text-darkTextSecondary">{strings.actions}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <Link to={editPath} className="w-full">
              <Button variant="primary" fullWidth size="md">{strings.edit}</Button>
            </Link>
            <Button onClick={handlePrintReceipt} variant="secondary" fullWidth size="md">{strings.printReceipt}</Button>
            <Button onClick={handlePrintLabel} variant="secondary" fullWidth size="md">{strings.printLabel}</Button>
            <Button onClick={handleDeleteOrder} variant="danger" fullWidth size="md" className="sm:col-span-2 md:col-span-1 md:mt-0 mt-2 sm:mt-0">{strings.delete}</Button>
          </div>
        </section>
      </div>
    </>
  );
};
