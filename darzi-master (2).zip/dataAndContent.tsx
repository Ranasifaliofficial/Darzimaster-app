
import React from 'react';
import { Order, TailorProfile, Language } from './types';

// App Configuration
export const APP_CONFIG = {
  appName: "Darzi Master", // Generic name, can be overridden by language strings if needed
  tagline: "Your Tailoring Assistant", // English default
  welcomeMessage: "Welcome to Darzi Master!", // English default
  copyrightText: `Darzi Master by Rana Asif Ali`, // Simplified copyright
  developerContact: "03370351173", 
  developerContactMessage: "For more information or support, contact:", // English default
  loadingMessage: "Welcome to Darzi Master — Powered by Rana Asif Ali",
  defaultUnit: "inch", // English default for unit if language is EN
  defaultUrduUnit: "انچ",
};

// Urdu UI Strings (Existing)
export const URDU_STRINGS = {
  // General
  save: "محفوظ کریں",
  cancel: "منسوخ کریں",
  edit: "ترمیم کریں",
  delete: "حذف کریں",
  next: "آگے بڑھیں",
  back: "پیچھے جائیں",
  preview: "پیش منظر",
  shareOrder: "آرڈر شیئر کریں",
  printLabel: "لیبل پرنٹ کریں",
  printReceipt: "رسید پرنٹ کریں",
  newOrder: "نیا آرڈر",
  orderHistory: "آرڈر ہسٹری",
  orderDetails: "آرڈر کی تفصیلات",
  searchOrders: "آرڈرز تلاش کریں",
  noOrdersFound: "کوئی آرڈر نہیں ملا۔",
  addFavorite: "پسندیدہ میں شامل کریں",
  removeFavorite: "پسندیدہ سے ہٹائیں",
  settings: "سیٹنگز",
  theme: "تھیم",
  language: "زبان",
  lightTheme: "لائٹ تھیم",
  darkTheme: "ڈارک تھیم",
  urdu: "اردو",
  english: "English",
  notes: "نوٹس / اضافی ہدایات",
  customerName: "گاہک کا نام",
  customerMobile: "گاہک کا موبائل نمبر",
  orderNumber: "آرڈر نمبر",
  orderDate: "آرڈر کی تاریخ",
  deliveryDate: "ڈیلیوری کی تاریخ",
  garmentType: "لباس کی قسم",
  measurements: "پیمائشیں",
  styleChoices: "اسٹائل کا انتخاب",
  label: "لیبل",
  clothVariety: "کپڑے کی قسم",
  receipt: "رسید",
  deleteConfirmation: "کیا آپ واقعی آرڈر نمبر",
  deleteConfirmationPrompt: "کو حذف کرنا چاہتے ہیں؟",
  lengthLabel: "لمبائی",
  sleeveLabelForLabel: "بازو",
  manualMeasurementsHeading: "پیمائشیں (دستی اندراج)",
  home: "ہوم",
  // Home Screen
  shalwarKameezTailoring: "شلوار قمیض سلائی",
  pantShirtTailoring: "پینٹ شرٹ سلائی",
  tailorProfile: "درزی پروفائل",

  // Shalwar Kameez specific (remains largely the same, just add English counterparts)
  shalwarDetails: "شلوار کی تفصیلات",
  kameezDetails: "قمیض کی تفصیلات",
  waistbandThickness: "کمر کی پٹی کی موٹائی",
  pocketChoice: "جیب کا انتخاب",
  sidePocket: "سائیڈ جیب",
  frontPocketLabel: "فرنٹ جیب", // Can be used for Shalwar front pocket if any
  noPocket: "جیب نہیں",
  bottomHemPancha: "نیچے کا گھیر (پنچا)", // پنچا is specific, might need "Bottom Hem" in EN
  cuffDetails: "کف کی تفصیلات",
  cuffThickness: "کف کی موٹائی",
  cuffStyle: "کف کا سٹائل",
  simpleCuff: "سادہ کف",
  roundCuff: "گول کف",
  squareCuff: "چورس کف",
  pointedCuff: "نوکدار کف",
  buttonsInCuff: "کف میں بٹن کی تعداد",
  pajamaStyle: "پاجامہ کی طرز",
  openStyle: "کھلا",
  tightStyle: "ٹائٹ",
  
  chest: "سینہ",
  waist: "کمر",
  hips: "کولہے",
  shoulder: "کندھے",
  sleeveLength: "بازو کی لمبائی",
  sleeveWidth: "بازو کی چوڑائی",
  collarSize: "کالر",
  neckOpening: "گلہ",
  collarStyle: "کالر کا انداز",
  collarBanStyle: "بین کالر",
  collarRegularStyle: "کالر", // Regular Collar
  roundNeckStyle: "گول گلہ",
  vNeckStyle: "وی-گلہ",
  sherwaniStyle: "شیروانی",
  placketFrontOpening: "پٹی یا فرنٹ اوپننگ",
  buttonPlacketLength: "بٹن پٹی کی لمبائی",
  frontPocketKameez: "فرنٹ جیب (قمیض)",
  yes: "ہاں",
  no: "نہیں",
  singlePocket: "ایک جیب",
  doublePocket: "دو جیبیں",
  straightPocket: "سیدھی جیب",
  angledPocket: "ترچھی جیب",
  buttonSize: "بٹن کا سائز",
  buttonCount: "بٹن کی تعداد",
  sideCut: "سائیڈ کٹ",

  // Pant Shirt specific
  pantDetails: "پینٹ کی تفصیلات",
  shirtDetails: "شرٹ کی تفصیلات",
  pantWaist: "کمر (پینٹ)",
  pantHip: "ہپ (پینٹ)",
  pantThigh: "تھائیز (پینٹ)",
  pantLength: "لمبائی (پینٹ)",
  frontPocketsPant: "فرنٹ جیبیں (پینٹ)",
  backPocketsPant: "بیک جیبیں (پینٹ)",
  beltLoops: "بیلٹ لوپس",
  closureType: "بندش کی قسم",
  zipOption: "زپ",
  buttonOption: "بٹن",
  pantBottomFolded: "فولڈ شدہ نچلا حصہ",
  pantBottomSimple: "سادہ نچلا حصہ",

  shirtCollar: "کالر (شرٹ)",
  shirtCuff: "کف (شرٹ)",
  shirtShoulder: "کندھے (شرٹ)",
  shirtChest: "چیسٹ (شرٹ)", // Chest for shirt
  shirtSleeveLength: "آستین کی لمبائی (شرٹ)",
  shirtSleeveWidth: "آستین کی چوڑائی (شرٹ)",
  shirtFrontButtonFull: "مکمل بٹن",
  shirtFrontButtonHalf: "ہاف پٹی",
  shirtFrontButtonNone: "بغیر بٹن",
  shirtPocketOne: "ایک جیب",
  shirtPocketTwo: "دو جیبیں",
  shirtPocketNone: "جیب نہیں",
  shirtSideCutLength: "سائیڈ کٹ کی لمبائی",

  // Image Receipt
  saveReceiptImage: "رسید کی تصویر محفوظ کریں",
  shareToWhatsApp: "واٹس ایپ پر شیئر کریں",
  receiptImageSaved: "رسید کی تصویر محفوظ ہوگئی!",
  receiptImageShared: "رسید واٹس ایپ پر شیئر ہوگئی۔",
  whatsappShareMessage: "آرڈر کی تفصیلات برائے مہربانی ملاحظہ فرمائیں۔ آرڈر نمبر: ",
  thankYouVisitAgain: "شکریہ! دوبارہ تشریف لائیں۔",
  shopName: "دکان کا نام", // Generic shop name
  tailorNameOnReceipt: "سینیئر درزی", // Placeholder for tailor name on receipt
  
  // Profile Screen
  profileScreenTitle: "درزی کی پروفائل",
  tailorNameLabel: "درزی کا نام",
  shopNameLabel: "دکان کا نام",
  addressLabel: "پتہ",
  phoneLabel: "فون نمبر",
  profilePictureLabel: "پروفائل تصویر",
  uploadImageButton: "تصویر اپلوڈ کریں",
  profileSavedSuccess: "پروفائل کامیابی سے محفوظ ہوگئی!",
  errorSavingProfile: "پروفائل محفوظ کرتے وقت خرابی ہوئی۔",
  errorLoadingProfile: "پروفائل لوڈ کرتے وقت خرابی ہوئی۔",
  maxFileSizeError: "فائل کا سائز 2MB سے زیادہ نہیں ہونا چاہیے۔",
  actions: "کاروائیاں",
  uniqueReceiptShare: "مخصوص رسید (برائے شیئرنگ)",
  searchPlaceholder: "تلاش کریں (نمبر، نام، موبائل)",
  pleaseWait: "برائے مہربانی انتظار کریں...",
  appTagline: APP_CONFIG.tagline, // Using default tagline for Urdu
  appWelcomeMessage: APP_CONFIG.welcomeMessage, // Using default welcome for Urdu
  appName: APP_CONFIG.appName,
  developerContactMessage: APP_CONFIG.developerContactMessage,
  // FIX: Add loadingMessage to URDU_STRINGS
  loadingMessage: "درزی ماسٹر میں خوش آمدید — پیش کردہ رانا آصف علی", 
};

// English UI Strings (Sample - needs full translation)
export const ENGLISH_STRINGS = {
  // General
  save: "Save",
  cancel: "Cancel",
  edit: "Edit",
  delete: "Delete",
  next: "Next",
  back: "Back",
  preview: "Preview",
  shareOrder: "Share Order",
  printLabel: "Print Label",
  printReceipt: "Print Receipt",
  newOrder: "New Order",
  orderHistory: "Order History",
  orderDetails: "Order Details",
  searchOrders: "Search Orders",
  noOrdersFound: "No orders found.",
  addFavorite: "Add to Favorites",
  removeFavorite: "Remove from Favorites",
  settings: "Settings",
  theme: "Theme",
  language: "Language",
  lightTheme: "Light Theme",
  darkTheme: "Dark Theme",
  urdu: "اردو",
  english: "English",
  notes: "Notes / Additional Instructions",
  customerName: "Customer Name",
  customerMobile: "Customer Mobile No.",
  orderNumber: "Order Number",
  orderDate: "Order Date",
  deliveryDate: "Delivery Date",
  garmentType: "Garment Type",
  measurements: "Measurements",
  styleChoices: "Style Choices",
  label: "Label",
  clothVariety: "Cloth Variety",
  receipt: "Receipt",
  deleteConfirmation: "Are you sure you want to delete order number",
  deleteConfirmationPrompt: "?",
  lengthLabel: "Length",
  sleeveLabelForLabel: "Sleeve", // For label context
  manualMeasurementsHeading: "Measurements (Manual Entry)",
  home: "Home",

  // Home Screen
  shalwarKameezTailoring: "Shalwar Kameez Tailoring",
  pantShirtTailoring: "Pant Shirt Tailoring",
  tailorProfile: "Tailor Profile",

  // Shalwar Kameez
  shalwarDetails: "Shalwar Details",
  kameezDetails: "Kameez Details",
  waistbandThickness: "Waistband Thickness",
  pocketChoice: "Pocket Choice",
  sidePocket: "Side Pocket",
  frontPocketLabel: "Front Pocket",
  noPocket: "No Pocket",
  bottomHemPancha: "Bottom Hem (Pancha)",
  cuffDetails: "Cuff Details",
  cuffThickness: "Cuff Thickness",
  cuffStyle: "Cuff Style",
  simpleCuff: "Simple Cuff",
  roundCuff: "Round Cuff",
  squareCuff: "Square Cuff",
  pointedCuff: "Pointed Cuff",
  buttonsInCuff: "Buttons in Cuff",
  pajamaStyle: "Pajama Style",
  openStyle: "Open",
  tightStyle: "Tight",
  
  chest: "Chest",
  waist: "Waist",
  hips: "Hips",
  shoulder: "Shoulder",
  sleeveLength: "Sleeve Length",
  sleeveWidth: "Sleeve Width",
  collarSize: "Collar Size",
  neckOpening: "Neck Opening",
  collarStyle: "Collar Style",
  collarBanStyle: "Ban Collar",
  collarRegularStyle: "Regular Collar",
  roundNeckStyle: "Round Neck",
  vNeckStyle: "V-Neck",
  sherwaniStyle: "Sherwani Collar",
  placketFrontOpening: "Placket / Front Opening",
  buttonPlacketLength: "Button Placket Length",
  frontPocketKameez: "Front Pocket (Kameez)",
  yes: "Yes",
  no: "No",
  singlePocket: "Single Pocket",
  doublePocket: "Double Pockets",
  straightPocket: "Straight Pocket",
  angledPocket: "Angled Pocket",
  buttonSize: "Button Size",
  buttonCount: "Button Count",
  sideCut: "Side Cut",

  // Pant Shirt
  pantDetails: "Pant Details",
  shirtDetails: "Shirt Details",
  pantWaist: "Waist (Pant)",
  pantHip: "Hip (Pant)",
  pantThigh: "Thighs (Pant)",
  pantLength: "Length (Pant)",
  frontPocketsPant: "Front Pockets (Pant)",
  backPocketsPant: "Back Pockets (Pant)",
  beltLoops: "Belt Loops",
  closureType: "Closure Type",
  zipOption: "Zip",
  buttonOption: "Button",
  pantBottomFolded: "Folded Bottom",
  pantBottomSimple: "Simple Bottom",

  shirtCollar: "Collar (Shirt)",
  shirtCuff: "Cuff (Shirt)",
  shirtShoulder: "Shoulder (Shirt)",
  shirtChest: "Chest (Shirt)",
  shirtSleeveLength: "Sleeve Length (Shirt)",
  shirtSleeveWidth: "Sleeve Width (Shirt)",
  shirtFrontButtonFull: "Full Button",
  shirtFrontButtonHalf: "Half Placket",
  shirtFrontButtonNone: "No Buttons",
  shirtPocketOne: "One Pocket",
  shirtPocketTwo: "Two Pockets",
  shirtPocketNone: "No Pocket",
  shirtSideCutLength: "Side Cut Length",

  // Image Receipt
  saveReceiptImage: "Save Receipt Image",
  shareToWhatsApp: "Share to WhatsApp",
  receiptImageSaved: "Receipt image saved!",
  receiptImageShared: "Receipt shared to WhatsApp.",
  whatsappShareMessage: "Please find the order details attached. Order No: ",
  thankYouVisitAgain: "Thank You! Visit Again.",
  shopName: "Shop Name", // Generic shop name
  tailorNameOnReceipt: "Tailor Name", // Placeholder for tailor name on receipt

  // Profile Screen
  profileScreenTitle: "Tailor Profile",
  tailorNameLabel: "Tailor's Name",
  shopNameLabel: "Shop Name",
  addressLabel: "Address",
  phoneLabel: "Phone Number",
  profilePictureLabel: "Profile Picture",
  uploadImageButton: "Upload Image",
  profileSavedSuccess: "Profile saved successfully!",
  errorSavingProfile: "Error saving profile.",
  errorLoadingProfile: "Error loading profile.",
  maxFileSizeError: "File size should not exceed 2MB.",
  actions: "Actions",
  uniqueReceiptShare: "Shareable Receipt",
  searchPlaceholder: "Search (No, Name, Mobile)",
  pleaseWait: "Please wait...",
  appTagline: APP_CONFIG.tagline,
  appWelcomeMessage: APP_CONFIG.welcomeMessage,
  appName: APP_CONFIG.appName,
  developerContactMessage: APP_CONFIG.developerContactMessage,
  // FIX: Add loadingMessage to ENGLISH_STRINGS
  loadingMessage: APP_CONFIG.loadingMessage,
};

export const LANG_STRINGS = {
  [Language.Urdu]: URDU_STRINGS,
  [Language.English]: ENGLISH_STRINGS,
};

// Default Base64 encoded transparent pixel or a simple placeholder icon
export const DEFAULT_AVATAR_BASE64 = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIGNsYXNzPSJsdWNpZGUgbHVjaWRlLXVzZXItcm91bmQiPjxyZWN0IHdpZHRoPSIxOCIgaGVpZ2h0PSIxOCIgeD0iMyIgeT0iMyIgcng9IjIiLz48Y2lyY2xlIGN4PSIxMiIgY3k9IjEwIiByPSI0Ii8+PHBhdGggZD0iTTM6MjAgYTQgNCAwIDAgMCA0LTRIYYy04Ii8+PC9zdmc+";


// SVG Icons as React Components
export const IconShalwarKameez: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2C11.4477 2 11 2.44772 11 3V6H7C6.44772 6 6 6.44772 6 7V10H4C3.44772 10 3 10.4477 3 11V21C3 21.5523 3.44772 22 4 22H9V17C9 16.4477 9.44772 16 10 16H14C14.5523 16 15 16.4477 15 17V22H20C20.5523 22 21 21.5523 21 21V11C21 10.4477 20.5523 10 20 10H18V7C18 6.44772 17.5523 6 17 6H13V3C13 2.44772 12.5523 2 12 2ZM13 8V10H17V8H13ZM7 8V10H11V8H7Z"/>
  </svg>
);

export const IconPantShirt: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 3H16L17 8H7L8 3Z M18 8H6L5 21H19L18 8Z M12 10C13.1046 10 14 10.8954 14 12V14H10V12C10 10.8954 10.8954 10 12 10Z M9 16H15V18H9V16Z"/>
  </svg>
);

export const IconSun: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-6.364-.386 1.591-1.591M3 12h2.25m.386-6.364 1.591 1.591M12 12a2.25 2.25 0 0 0-2.25 2.25v.001A2.25 2.25 0 0 0 12 12Zm0 0a2.25 2.25 0 1 1 0 4.5 2.25 2.25 0 0 1 0-4.5Z" />
  </svg>
);

export const IconMoon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21c3.007 0 5.71-1.096 7.722-2.876Z" />
  </svg>
);

export const IconSave: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 3.75H6.912a2.25 2.25 0 0 0-2.15 1.948L4.5 5.25v13.5A2.25 2.25 0 0 0 6.75 21h10.5A2.25 2.25 0 0 0 19.5 18.75V10.5c0-1.205-.798-2.234-1.908-2.576L17.25 7.5V5.25A2.25 2.25 0 0 0 15 3H12m-3 0a2.25 2.25 0 0 1 2.25-2.25h1.5A2.25 2.25 0 0 1 15 3.75M9 3.75v1.5H15v-1.5M12 12.75a.75.75 0 0 0-.75.75v4.5a.75.75 0 0 0 1.5 0v-4.5a.75.75 0 0 0-.75-.75Z" />
  </svg>
);

export const IconDownload: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);

export const IconWhatsApp: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.33 3.43 16.79L2 22L7.32 20.61C8.75 21.38 10.36 21.82 12.04 21.82C17.5 21.82 21.95 17.37 21.95 11.91C21.95 6.45 17.5 2 12.04 2ZM12.04 20.13C10.52 20.13 9.07 19.73 7.82 19L7.42 18.76L4.2 19.58L5.05 16.47L4.8 16.05C4.09 14.73 3.75 13.24 3.75 11.91C3.75 7.36 7.49 3.69 12.04 3.69C16.59 3.69 20.33 7.36 20.33 11.91C20.33 16.47 16.59 20.13 12.04 20.13ZM17.29 14.47C17.08 14.36 16.03 13.84 15.83 13.76C15.62 13.68 15.47 13.64 15.31 13.89C15.15 14.14 14.66 14.69 14.51 14.85C14.35 15.01 14.19 15.04 13.98 14.93C13.77 14.82 12.95 14.54 11.94 13.66C11.15 12.98 10.64 12.14 10.48 11.89C10.32 11.64 10.42 11.52 10.53 11.41C10.63 11.31 10.76 11.14 10.89 11C11.02 10.86 11.07 10.75 11.18 10.54C11.28 10.33 11.23 10.16 11.15 10.01C11.07 9.85 10.56 8.59 10.35 8.06C10.15 7.53 9.94 7.59 9.79 7.59C9.68 7.59 9.52 7.59 9.36 7.59C9.2 7.59 8.94 7.65 8.73 7.89C8.52 8.14 7.91 8.69 7.91 9.85C7.91 11.01 8.76 12.11 8.91 12.27C9.07 12.43 10.53 14.69 12.69 15.54C13.23 15.76 13.64 15.91 13.95 16.03C14.44 16.21 14.85 16.18 15.15 16.12C15.5 16.04 16.41 15.48 16.59 14.9C16.77 14.32 16.77 13.85 16.72 13.76C16.67 13.68 16.52 13.62 16.32 13.51C16.11 13.41 17.5 14.58 17.29 14.47Z"/>
    </svg>
);

export const IconPlus: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
  </svg>
);

export const IconChevronLeft: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
  </svg>
);

export const IconChevronRight: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
  </svg>
);

export const IconStarFilled: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354l-4.543 2.733c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434 2.082-5.005Z" clipRule="evenodd" />
  </svg>
);

export const IconStarOutline: React.FC<{ className?: string }> = ({ className }) => (
 <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.619.049.875.87.421 1.317l-4.135 3.652a.563.563 0 0 0-.162.522l1.204 5.667c.124.582-.503 1.028-1.012.737L12 19.222l-4.995 2.883c-.51.291-1.136-.155-1.012-.737l1.204-5.667a.563.563 0 0 0-.162-.522L3.07 10.716c-.453-.447-.198-1.268.42-1.317l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5Z" />
  </svg>
);

export const IconProfile: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
    <path fillRule="evenodd" d="M4 4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H4Zm10 5a1 1 0 0 1 1-1h3a1 1 0 1 1 0 2h-3a1 1 0 0 1-1-1Zm0 3a1 1 0 0 1 1-1h3a1 1 0 1 1 0 2h-3a1 1 0 0 1-1-1Zm0 3a1 1 0 0 1 1-1h3a1 1 0 1 1 0 2h-3a1 1 0 0 1-1-1Zm-8-5a3 3 0 1 1 6 0 3 3 0 0 1-6 0Zm1.942 4a3 3 0 0 0-2.847 2.051l-.044.133-.004.012c-.042.126-.055.167-.042.195.006.013.02.023.038.039.032.025.08.064.146.155A1 1 0 0 0 6 17h6a1 1 0 0 0 .811-.415.713.713 0 0 1 .146-.155c.019-.016.031-.026.038-.04.014-.027 0-.068-.042-.194l-.004-.012-.044-.133A3 3 0 0 0 10.059 14H7.942Z" clipRule="evenodd"/>
  </svg>
);

export const IconCamera: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.774 48.774 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0ZM18.75 10.5h.008v.008h-.008V10.5Z" />
  </svg>
);

export const IconHome: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" />
  </svg>
);

export const IconLanguage: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 21l5.25-11.25L21 21m-9-3h7.5M3 5.621a48.474 48.474 0 016-.371m0 0c1.12 0 2.233.038 3.334.114M9 5.25V3m3.334 2.364C11.176 10.658 7.69 15.08 3 17.502m9.334-12.138c.896.061 1.785.147 2.666.257m-4.589 8.495a18.023 18.023 0 01-3.827-5.802" />
  </svg>
);

// New Tailoring Icons
export const IconScissors: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
        <circle cx="6" cy="6" r="3" />
        <circle cx="6" cy="18" r="3" />
        <line x1="20" y1="4" x2="8.12" y2="15.88" />
        <line x1="14.47" y1="14.48" x2="20" y2="20" />
        <line x1="8.12" y1="8.12" x2="12" y2="12" />
    </svg>
);

export const IconMeasuringTape: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.75V6m0 0V8.25m0-2.25H12m3.75 0H21m-8.625 3.75h.375m-.375 0H3.375m6.375 0V15m0-2.25v-2.25m0 0h-.375m.375 0h.375m0 0H21m-2.25 0v2.25m0 0v2.25m0 0h2.25M12 18.75v-2.25m0 0H9.75m2.25 0h2.25m0 0H21M3 3h18v18H3V3z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 6h.008v.008H9V6zm-.75 3.75h.008v.008H8.25v-.008zm.75 3.75h.008v.008H9v-.008zm-.75 3.75h.008v.008H8.25v-.008zM15 6h.008v.008H15V6zm-.75 3.75h.008v.008h-.008v-.008zm.75 3.75h.008v.008h-.008v-.008zm-.75 3.75h.008v.008h-.008v-.008z" />
    </svg>
);

export const IconSewingMachine: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M20 9V6a2 2 0 00-2-2H6a2 2 0 00-2 2v3m16 0h-5.586a1 1 0 01-.707-.293L12 7.414l-1.707 1.293A1 1 0 019.586 9H4m16 0v11a2 2 0 01-2 2H6a2 2 0 01-2-2V9m16 0H4m14 6a2 2 0 11-4 0 2 2 0 014 0zM8 15a1 1 0 100-2 1 1 0 000 2z" />
    </svg>
);

export const IconNeedleThread: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 4.5l-9 9 1.5 1.5 9-9-1.5-1.5z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.375 19.125l-1.5-1.5M19.5 8.625l-1.5-1.5" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 15V3M9 6h6M9 9h6m-1.5 13.5c2.667-1.5 4.5-4.5 4.5-7.5 0-5-3.358-7.5-7.5-7.5S4.5 5.5 4.5 10.5c0 3 1.833 6 4.5 7.5z" />
    </svg>
);

export const IconMannequin: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4a2 2 0 100-4 2 2 0 000 4z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v4m0 0c-2 0-4 1-4 3s2 3 4 3 4-1 4-3-2-3-4-3zm0 10v4m-2 0h4" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 6.5s-1 2-1 4.5c0 2.582 2 4.5 4 4.5s4-1.918 4-4.5S15 6.5 15 6.5" />
    </svg>
);

// Order Service (localStorage based)
const ORDERS_STORAGE_KEY = 'darziMasterOrders';

export const orderService = {
  getOrders: async (): Promise<Order[]> => {
    const ordersJson = localStorage.getItem(ORDERS_STORAGE_KEY);
    return ordersJson ? JSON.parse(ordersJson) : [];
  },

  getOrderById: async (id: string): Promise<Order | undefined> => {
    const orders = await orderService.getOrders();
    return orders.find(order => order.id === id);
  },

  saveOrder: async (order: Order): Promise<Order> => {
    const orders = await orderService.getOrders();
    const existingIndex = orders.findIndex(o => o.id === order.id);
    if (existingIndex > -1) {
      orders[existingIndex] = order;
    } else {
      orders.push(order);
    }
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
    return order;
  },

  deleteOrder: async (id: string): Promise<void> => {
    let orders = await orderService.getOrders();
    orders = orders.filter(order => order.id !== id);
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
  },

  generateOrderNumber: async (): Promise<string> => {
    const orders = await orderService.getOrders();
    const date = new Date();
    const prefix = `DM-${date.getFullYear().toString().slice(-2)}${(date.getMonth() + 1).toString().padStart(2, '0')}${date.getDate().toString().padStart(2, '0')}-`;
    let nextId = 1;
    orders.forEach((o: Order) => { 
        if (o.orderNumber.startsWith(prefix)) {
            const num: number = parseInt(o.orderNumber.substring(prefix.length), 10); 
            if (!isNaN(num) && num >= nextId) {
                nextId = num + 1;
            }
        }
    });
    return `${prefix}${nextId.toString().padStart(3, '0')}`;
  }
};

// Profile Service (localStorage based)
const PROFILE_STORAGE_KEY = 'darziMasterProfile';

export const profileService = {
  getProfile: async (): Promise<TailorProfile | null> => {
    const profileJson = localStorage.getItem(PROFILE_STORAGE_KEY);
    if (profileJson) {
        const profile = JSON.parse(profileJson);
        // Ensure essential fields have defaults if missing from older stored profiles
        return {
            tailorName: profile.tailorName || '',
            shopName: profile.shopName || '',
            address: profile.address || '',
            phone: profile.phone || '',
            profileImageBase64: profile.profileImageBase64 || null,
        };
    }
    return null;
  },
  saveProfile: async (profile: TailorProfile): Promise<void> => {
    localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
  }
};
